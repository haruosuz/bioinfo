#' ---
#' title: "DATA SCIENCE FOR GENOME DYNAMICS"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Clear R's environment
rm(list = ls())

# Load the packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(zoo)
library(Biostrings)
library(msa)
library(ape)
library(microseq)

#' # 1
#' ## 1-1
#' ### 1-1-1
#' # DNA Sequence Statistics (1)
#' # DNA Sequence Statistics (2)
#' # Dotplot
#' # Pairwise Sequence Alignment
#' 
#' ## [10.2 Namespace](https://r-pkgs.org/namespace.html)
#?count
#?dplyr::count
#?seqinr::count

#?translate
#?microseq::translate
#?Biostrings::translate
#?seqinr::translate

#?as.alignment
#?seqinr::as.alignment
#?ape::as.alignment

#' # References
#' - https://github.com/haruosuz/DS4GD/tree/master/2023-10
#' - https://artic.network/how-to-read-a-tree.html
#' - 
#' 
#' # Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
