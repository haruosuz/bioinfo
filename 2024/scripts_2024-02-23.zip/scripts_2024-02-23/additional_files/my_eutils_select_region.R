rm(list = ls()) # Clear R's environment

#' - seqinr https://seqinr.r-forge.r-project.org/
#'   - https://seqinr.r-forge.r-project.org/seqinr_3_1-5.pdf
#'
#' ## 2.5 About getting started
library(seqinr) #  load the seqinR package

#' - [MEGA](https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#mega)
#' [Choosing and Acquiring Sequences Part 1](https://youtu.be/raaOgtvMJWw?t=698)
#' 
#' - https://www.ncbi.nlm.nih.gov/nucleotide/CP028704
#' Escherichia coli strain VH1 chromosome, complete genome
#' ```
#' CDS             326873..327322
#' /product="evolved beta-galactosidase subunit beta"
#' ```
my_id <- "CP028704" # accession
my_strand <- 1 # plus strand
#my_strand <- 2 # minus strand
my_seq_start <- 326873 # First sequence base to retrieve
my_seq_stop <- 327322 # Last sequence base to retrieve
#' - [The Entrez Programming Utilities (E-utilities)](https://github.com/haruosuz/bioinfo/blob/master/references/README.bioinfo.tools.md#e-utilities)
url <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",my_id,"&strand=",my_strand,"&seq_start=",my_seq_start,"&seq_stop=",my_seq_stop,"&rettype=fasta&retmode=text")
#' ### 3.1.2 The function read.fasta()
myseq <- read.fasta(file=url, seqtype="DNA", strip.desc=TRUE)[[1]]

#' ### 3.1.3 The function write.fasta()
# Writing sequence data out as a FASTA file
dir.create(path="data", recursive=TRUE)
write.fasta(sequences=myseq, names=getAnnot(myseq), file.out=paste0("data/",my_id,".",my_strand,".",my_seq_start,"-",my_seq_stop,".fna"), nbchar=max(getLength(myseq)))

#' ## 6.2 Generic methods for sequences
getLength(myseq) # the length of a sequence
getName(myseq) # the name of a sequence
getAnnot(myseq) # sequence annotations
getTrans(myseq) # translation into amino-acids
c2s(getTrans(myseq)) # be coerced as string of character
table(aaa(getTrans(myseq)))

#' ### 6.3.1 Sequences as vectors of characters
#dnafile <- system.file("sequences/malM.fasta", package = "seqinr")
#myseq <- read.fasta(file = dnafile)[[1]]
#' The following code was used to display (cf figure 6.3) the codon usage in the sequence:
codonusage <- uco(myseq)
codonusage
my.dotchart.uco <- dotchart.uco(codonusage, cex=0.5, main = paste("Codon usage in", getName(myseq)))
names(my.dotchart.uco)
sapply(my.dotchart.uco, length)
d.f <- data.frame(my.dotchart.uco[2:4])

# Exporting Data
write.table(d.f, file="R.uco.tsv", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
write.csv(d.f, file="R.uco.csv", quote=TRUE)

#getwd()
#list.files()
sessionInfo()
Sys.time()
