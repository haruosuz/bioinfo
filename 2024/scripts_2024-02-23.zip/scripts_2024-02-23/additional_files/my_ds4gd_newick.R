#' ---
#' title: "DS4GD_newick"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())
library(ape)
#?ape::plot.phylo

#' # newick
#' - https://en.wikipedia.org/wiki/Newick_format
#?ape::read.tree
layout(matrix(1:4, 2, 2))

txt <- "((A,B,C),D);"
tr <- read.tree(text=txt); plot(tr, main=txt)

txt <- "((A:0.05,B:0.2,C:0.1):0.3,D:0.4);"
tr <- read.tree(text=txt); plot(tr, main=txt)
add.scale.bar()

txt <- "((A:0.05,B:0.2,C:0.1)Ancestor:0.3,D:0.4)R;"
tr <- read.tree(text=txt); plot(tr, main=txt)
nodelabels(tr$node.label)
#names(tr)
#write.tree(tr)
write.tree(tr, file="myNewick.tre")
#read.tree(file="myNewick.tre")

#' - http://tree.bio.ed.ac.uk/software/figtree/
#' 
#' # rotate
#' - https://yulab-smu.top/treedata-book/faq.html#branch-setting
#?ape::ladderize
layout(matrix(1:4, 2, 2))
txt <- "(E, ((C, (A, B)), D));"
txt <- "(Fishes, ((Lizards, (Chimps, Humans)), Frogs));"
tr <- read.tree(text=txt); plot(tr, main="normal")
tr <- ladderize(tr, right=T); plot(tr, main="right-ladderized")
tr <- ladderize(tr, right=F); plot(tr, main="left-ladderized")
tr <- rotateConstr(tr, constraint=read.tree(text=txt)$tip.label); plot(tr, main="rotateConstr")
write.tree(tr)

#' # root
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma99275963904031
#' Welcome to the Microbiome
#' - https://www.brh.co.jp/research/formerlab/miyata/2005/post_000008.php
#?ape::root
layout(matrix(1:4, 2, 2))
txt <- "(Eukarotes, Archaea, Bacteria);"
tr <- read.tree(text=txt)
mytype <- "unrooted"; plot(tr, type=mytype, main=mytype)
ogp <- "Eukarotes"; tr <- root(tr, outgroup=ogp, r=TRUE); plot(tr, main=paste("outgroup:",ogp))
ogp <- "Archaea"; tr <- root(tr, outgroup=ogp, r=TRUE); plot(tr, main=paste("outgroup:",ogp))
ogp <- "Bacteria"; tr <- root(tr, outgroup=ogp, r=TRUE); plot(tr, main=paste("outgroup:",ogp))
#is.rooted(tr)

#' # monophyletic
#' - https://en.wikipedia.org/wiki/Monophyly
#' - https://en.wikipedia.org/wiki/Paraphyly
#' ![https://www.numerade.com/ask/question/the-phylogenetic-tree-below-shows-the-relationship-between-bacteria-archaea-and-eukaryotes-select-the-wrong-statement-about-the-tree-from-the-following-bacteria-prokaryotes-archaea-eukaryote-78113/](https://cdn.numerade.com/ask_images/da888612ab4943e3acffead35b71f637.jpg)
#ape::is.monophyletic(phy = tr, tips = c("Archaea", "Bacteria"))

# Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
