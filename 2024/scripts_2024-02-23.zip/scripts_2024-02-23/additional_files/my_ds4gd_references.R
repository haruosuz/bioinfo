#' ---
#' title: "DS4GD_references"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---
#' 
#' # References
#' 
#' - [Which came first: the chicken or the egg? - Curious](https://www.science.org.au/curious/earth-environment/which-came-first-chicken-or-egg)
#' - https://pubmed.ncbi.nlm.nih.gov/21238242
#' Trends Ecol Evol. 1998 Apr 1;13(4):158. doi: 10.1016/s0169-5347(98)01362-7.
#' - 
#' - https://epirhandbook.com/en/phylogenetic-trees.html
#' 15 Phylogenetic trees | The Epidemiologist R Handbook
#' - https://epirhandbook.com/jp/phylogenetic-trees.html
#' 38 系統樹 | 疫学のための R ハンドブック
#' 
#' - https://artic.network/how-to-read-a-tree.html
#' - 
#' - 11/7/2017 [Module 24: An Intro to Phylogenetic Tree Construction in R](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html)
#'   - [Distance-based methods](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html#distance-based_methods)
#'   The following figure can help visually distinguish UPGMA methods from neighbor-joining methods (you can ignore single linkage and complete linkage)
#' 
#' ## 2021-12-25 バイオインフォマティクス入門 第2版
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926623411304034
#' Maruzen eBook Library
#' - https://www.keio-up.co.jp/np/isbn/9784766427912/
#' - https://www.keio-up.co.jp/np/detail_contents.do?goods_id=6182
#' 第3章　配列解析
#' 3ー2　配列アラインメント：動的計画法による配列アラインメントの計算
#' 3ー3　スコア行列：アミノ酸の類似性スコアとその統計的評価
#' 3ー4　高速な類似配列検索：高速に配列を比較するための計算技術
#' 3ー5　ホモロジー検索：高速にホモロジー検索するためのプログラム
#' 3ー6　マルチプルアラインメント：マルチプルアラインメントによる配列の多重比較
#' 
#' 第5章　遺伝・進化解析
#' 5ー6　分子進化：分子進化の中立説と分子時計
#' 5ー7　進化系統樹：進化系統樹の表現方法
#' 5ー8　パラログ・オーソログ：進化系統樹によるホモログ・パラログ・オーソログの解析
#' 5ー9　系統推定アルゴリズム：系統樹をつくるための系統推定アルゴリズム
#' 
#' ## 2021-05 Mastering Python for Bioinformatics by Ken Youens-Clark
#' - https://www.oreilly.com/library/view/mastering-python-for/9781098100872/
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926722992204034
#' Ebook Central Perpetual, DDA and Subscription Titles
#' 
#' ## 2018-11-19 よくわかるバイオインフォマティクス入門
#' - https://www.kspub.co.jp/book/detail/5138212.html
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma9926580096704034
#' Maruzen eBook Library
#' 
#' ## 2018.5 再現可能性のすゝめ ―RStudioによるデータ解析とレポート作成―（Wonderful R 3）
#' - https://www.kyoritsu-pub.co.jp/book/b10003938.html
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926579997904034
#' Maruzen eBook Library
#' 
#' ## Emmanuel Paradis (2012) "Analysis of Phylogenetics and Evolution with R" 2nd ed.
#' - https://github.com/haruosuz/books/tree/master/aper
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma99186639204031
#' SpringerLink Books (Series & Reference Works)
#' 
#' ## Ziheng Yang (2006) "Computational Molecular Evolution"
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma99159251504031
#' Ebook Central Academic Complete
#' - http://abacus.gene.ucl.ac.uk/CME/
#'   - http://abacus.gene.ucl.ac.uk/CME/TableOfContents.pdf
#' 
#' 
#' 