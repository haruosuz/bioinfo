# Clear R's environment
rm(list = ls())
#' - https://cran.r-project.org/mirrors.html
# URLs of the repositories for use by install.packages
#options(repos="https://cran.ism.ac.jp/")

#' - https://www.jstatsoft.org/article/view/v104i03
#' AMR: An R Package for Working with Antimicrobial Resistance Data | Journal of Statistical Software
#' 
#' - https://cran.r-project.org/package=AMR
#' AMR: Antimicrobial Resistance Data Analysis
#' 
#' - https://github.com/msberends/AMR
#install.packages("AMR")

#' - https://msberends.github.io/AMR/
#' 
#' # The AMR Package for R
#' 
#' - https://msberends.github.io/AMR/#get-this-package
#' 
#' ## Get this package
#' ### Latest official version
#install.packages("AMR")

#' - https://msberends.github.io/AMR/#get-started
#' 
#' ## Get started
#' To find out how to conduct AMR data analysis, 
#' please continue reading here to get started
#' https://msberends.github.io/AMR/articles/AMR.html
#' or click a link in the ‘How to’ menu.
#' https://msberends.github.io/AMR/articles/
#' 
#' 
#' https://msberends.github.io/AMR/index.html#practical-examples
#' 
#' ## Practical examples
#' ### Filtering and selecting data
# AMR works great with dplyr, but it's not required or neccesary
library(AMR)
library(dplyr)

example_isolates %>%
  mutate(bacteria = mo_fullname()) %>%
  filter(mo_is_gram_negative(),
         mo_is_intrinsic_resistant(ab = "cefotax")) %>%
  select(bacteria,
         aminoglycosides(),
         carbapenems())

#' https://msberends.github.io/AMR/#what-else-can-you-do-with-this-package
#' ## What else can you do with this package?
#' 
#' Reference for the taxonomy of microorganisms, since the package contains all microbial (sub)species from the List of Prokaryotic names with Standing in Nomenclature (LPSN) and the Global Biodiversity Information Facility (GBIF) (manual)
#' https://msberends.github.io/AMR/reference/mo_property.html
#' Get Properties of a Microorganism — mo_property • AMR (for R)
#' https://msberends.github.io/AMR/reference/mo_property.html#ref-examples
# get a list with the complete taxonomy (from kingdom to subspecies)
mo_taxonomy("Klebsiella pneumoniae")

# get a list with the taxonomy, the authors, Gram-stain,
# SNOMED codes, and URL to the online database
mo_info("Klebsiella pneumoniae")

#sessionInfo()
Sys.time()

#' https://cran.r-project.org/web/views/Epidemiology.html
#' AMR: Functions to simplify and standardise antimicrobial resistance (AMR) data analysis and to work with microbial and antimicrobial properties by using evidence-based methods and reliable reference data such as LPSN (Parte et al. 2020).
#' 

