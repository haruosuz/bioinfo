#' - https://cran.r-project.org/package=rentrez
#install.packages("rentrez")
library(rentrez)

# Please replace the following accession numbers:
accessions <- c("CP006601", "CP050254", "AP021897", "CP045833", "CP043872", "CP033354", "CP010418")

# Function to extract collection date, country, and PubMed information for a single accession
get_collection_info <- function(acc) {
  # Fetch GenBank data
  genbank_data <- entrez_fetch(db = "nuccore", id = acc, rettype = "gb", retmode = "text")
  
  # Extract lines containing collection date, country, and PUBMED information
  collection_date_lines <- grep("collection_date", readLines(textConnection(genbank_data)), value = TRUE)
  country_lines <- grep("/country", readLines(textConnection(genbank_data)), value = TRUE)
  pubmed_lines <- grep("   PUBMED", readLines(textConnection(genbank_data)), value = TRUE)
  
  # Initialize variables to store information
  collection_date <- country <- pubmed_id <- "NA" # Not Available

  # Extract collection date information
  if (length(collection_date_lines) > 0) {
    for (raw_date in collection_date_lines) {
      raw_date <- gsub(' +/*collection_date=', '', raw_date)
      raw_date <- gsub(' +/*collection_date +:: +', '', raw_date)
      raw_date <- gsub('"', '', raw_date)
      
      # Format the date based on different patterns
      if (grepl("^\\d{4}-\\d{2}-\\d{2}$", raw_date)) {
        collection_date <- raw_date
      } else if (grepl("^\\d{4}-\\d{2}$", raw_date)) {
        collection_date <- format(as.Date(paste0(raw_date, "-01"), format="%Y-%m-%d"), "%Y-%m")
      } else if (grepl("^\\d{4}$", raw_date)) {
        collection_date <- raw_date
      } else if (grepl("^\\d{2}-[A-Za-z]{3}-\\d{4}$", raw_date)) {
        collection_date <- format(as.Date(raw_date, format="%d-%b-%Y"), "%Y-%m-%d")
      } else if (grepl("^[A-Za-z]{3}-\\d{4}$", raw_date)) {
        collection_date <- format(as.Date(paste0("01-", raw_date), format="%d-%b-%Y"), "%Y-%m")
      } else {
        collection_date <- "Unknown Format"
      }
    }
  }
  
  # Extract country information
  if (length(country_lines) > 0) {
    raw_country <- gsub(' +/*country=', '', country_lines[1])
    raw_country <- gsub('"', '', raw_country)
    country <- raw_country
  }
  
  # Extract PUBMED information
  if (length(pubmed_lines) > 0) {
    pubmed_id <- gsub("   PUBMED", "", pubmed_lines[1])
  }
  
  # Return the result
  return(data.frame(accession = acc, collection_date = collection_date, country = country,
                    PUBMED = pubmed_id, stringsAsFactors = FALSE))
}

#' - https://www.ncbi.nlm.nih.gov/nuccore/CP010418
#accession <- "CP010418"; get_collection_info(accession)

# Apply the function to each accession in a list using lapply
result_list <- lapply(accessions, get_collection_info)

# Combine the results into a data frame
result_df <- do.call(rbind, result_list)

# Print the result
print(result_df)

# Save the result_df data frame as a TSV file
write.table(result_df, "R.rentrez.collection_date.country.pubmed.tsv", sep = "\t", quote = FALSE, row.names = FALSE)

