#' # assignment
#' ## [ペアワイズ配列アラインメント](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#pairwise-sequence-alignment)
#' ## [Pairwise Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html)
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#exercises)
#' - [Answers to the exercises on Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#sequence-alignment)

#+ echo = FALSE
# clear the decks
rm(list = ls())

#+ message = FALSE
# load the packages
library(seqinr)
library(Biostrings)

#' Answer the following questions. 
#' For each question, please record your answer, and what you typed into R to get this answer.
#' 
#' ### Q1. 
#' Download FASTA-format files of two protein sequences of interest from UniProt.

# Chorismate pyruvate-lyase OS=Mycobacterium
accession1 <- "Q9CD83" # PHBS_MYCLE
accession2 <- "A0PQ23" # A0PQ23_MYCUA
chars1 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
#write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

# conversion of a vector of chars into a string
string1 <- c2s(chars1)
string2 <- c2s(chars2)

# convert strings to uppercase 
STRING1 <- toupper(string1)
STRING2 <- toupper(string2)

#' ### Q2. 
#' What is the alignment score for the optimal global alignment between the two proteins, 
#' when you use the BLOSUM62 scoring matrix (substitution matrix), 
#' a gap opening penalty of -9.5 and a gap extension penalty of -0.5?
data(BLOSUM62) # load the BLOSUM62 scoring matrix
AlignGlobal_BLOSUM62 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                         gapOpening = 9.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM62

#' The alignment score is 557.
#' 
#' ### Q3. 
#' Use the writePairwiseAlignments() function to view the optimal global alignment.

writePairwiseAlignments(AlignGlobal_BLOSUM62)

#' The two sequences had alignment length of 220, with 121 (55.0%) identities and 18 (8.2%) gaps.
#' The position in the protein of the amino acid that is at the end of 
#' each line of the printed alignment is shown after the end of the line. 
#' For example, the first line of the alignment above finishes at amino acid position 40 
#' in the P1 sequence and also at amino acid position 50 in the S1 sequence.
#' Since we are printing out an alignment that contained gaps in the first 50 alignment columns, 
#' the first 50 alignment columns ends before the 50th amino acid in the P1 sequence.
#' 
#' ### Q4. 
#' Check if the alignment made using the BLOSUM80 or BLOSUM45 scoring matrix 
#' (substitution matrix) is different from that when BLOSUM62 is used.
#' BLOSUM62 is the default matrix for protein BLAST.
#' BLOSUM80 is used for more closely related alignments, and 
#' BLOSUM45 is used for more distantly related alignments.
#data(package="Biostrings")

data(BLOSUM80) # load the BLOSUM80 scoring matrix
AlignGlobal_BLOSUM80 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM80", 
                         gapOpening = 9.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM80
#writePairwiseAlignments(AlignGlobal_BLOSUM80)

data(BLOSUM45) # load the BLOSUM45 scoring matrix
AlignGlobal_BLOSUM45 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM45", 
                         gapOpening = 9.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM45
#writePairwiseAlignments(AlignGlobal_BLOSUM45)

#' The alignment made using BLOSUM45 or BLOSUM80 is actually the same as that made using BLOSUM62, 
#' so it doesn’t matter which scoring matrix we use in this case.
#' 
#' ### Q5. 
#' Change gap penalties to adjust alignment scores based on the number and length of gaps 
#' (e.g., set “gapOpening” to be 1.5 and “gapExtension” to be 0.5).

AlignGlobal_BLOSUM62_gap <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                             gapOpening = 1.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM62_gap
#writePairwiseAlignments(AlignGlobal_BLOSUM62_gap)

#' ### Q6. 
#' Check if the optimal local alignment is different from the optimal global alignment.
AlignLocal_BLOSUM62 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                        gapOpening = 9.5, gapExtension = 0.5, type="local")
AlignLocal_BLOSUM62
#writePairwiseAlignments(AlignLocal_BLOSUM62)

#' We see that the optimal local alignment is quite similar to the optimal global alignment 
#' in this case, except that it excludes a short region of poorly aligned sequence 
#' at the start and at the ends of the two proteins.
#' 
# Print R version and packages
sessionInfo()
Sys.time()

