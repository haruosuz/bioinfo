#' # Bioinformatic Analyses of Genome Sequence Data
#' Analyzing genome features, local variation in base composition: GC content and GC skew.
#' 
#' ### References
#' - [よくわかるバイオインフォマティクス入門](https://www.kspub.co.jp/book/detail/5138212.html)
#'   p.83
#'    - ６章　ゲノム解析
#'      - 6.2.1　ゲノムの特徴
#'        - A. ゲノムサイズと遺伝子数
#'        - B. GC含量（GC content）
#'        - C. GC skew
#' - [Genome signature](https://github.com/haruosuz/DS4GD/blob/master/2018/CaseStudy.md#genome-signature)
#' - [NCBI Genome List](https://github.com/haruosuz/DS4GD/blob/master/2020/CaseStudy.md#ncbi-genome-list)
#' - [Installing R packages](https://github.com/haruosuz/DS4GD/blob/master/2020/CaseStudy.md#assignment-2)
#' 
#+ echo = FALSE
# Clear the decks
rm(list = ls())

#+ message = FALSE
# libraries I need (no need to install...)
library(seqinr)
library(zoo) # rollapply

# Retrieving a DNA sequence from NCBI
ACCESSION <- "NC_000913" # RefSeq # Escherichia coli str. K-12 substr. MG1655
#ACCESSION <- "U00096.3" # INSDC # Escherichia coli str. K-12 substr. MG1655
#ACCESSION <- "NC_002528" # Buchnera aphidicola str. APS (Acyrthosiphon pisum)	
ACCESSION <- "NC_007795" # Staphylococcus aureus subsp. aureus NCTC 8325

filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")
seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)

# get the number of elements
length(seqs)
  
# store the first element of the list object `seqs` in a variable `seq1`
seq1 <- seqs[[1]]

getAnnot(seq1)

#' - [DNA Sequence Statistics (1)](https://github.com/haruosuz/DS4GD/blob/master/2018/CaseStudy.md#dna-sequence-statistics-1)
#' 
# Length of a DNA sequence
length(seq1)

# Base composition of a DNA sequence
table(seq1)

# GC Content of DNA
GC(seq1)

# Object Summaries # $length $composition $GC
summary(seq1)

# DNA words
count(seq1, 2)

#' - [DNA Sequence Statistics (2)](https://github.com/haruosuz/DS4GD/blob/master/2018/CaseStudy.md#dna-sequence-statistics-2)
#' 
# x-axis: Position
xlab <- "Position (Mbp)"
windowsize <- 10000
#windowsize <- round(length(seq1) / 50)
x <- seq(from = 1, to = length(seq1)-windowsize, by = windowsize) / 10^6

# y-axis: GC content = (G + C)/(A + T + G + C)
ylab <- "GC content"
y <- rollapply(data = seq1, width = windowsize, by = windowsize, FUN = GC)
plot(x, y, type="l", xlab=xlab, ylab=ylab)

# y-axis: GC skew = (G - C)/(G + C) or (C - G)/(C + G)
ylab <- "GC skew"
GCskew <- function(x){ y <- table(x); (y["c"] - y["g"]) / (y["c"] + y["g"]) }
GCskew <- function(x){ y <- table(x); (y["g"] - y["c"]) / (y["g"] + y["c"]) }
y <- rollapply(data = seq1, width = windowsize, by = windowsize, FUN = GCskew)
plot(x, y, type="l", xlab=xlab, ylab=ylab)
abline(h = 0)

# y-axis: Cumulative GC skew
ylab <- "Cumulative GC skew"
plot(x, cumsum(y), type="l", xlab=xlab, ylab=ylab)

#' 
sessionInfo()
Sys.time()

