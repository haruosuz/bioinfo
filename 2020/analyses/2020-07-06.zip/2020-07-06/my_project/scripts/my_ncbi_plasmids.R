#' # plasmids.txt
#' Plasmid genome sequencing projects
#' 
#+ echo = FALSE
# clear the decks
rm(list = ls())

#+ message = FALSE
# libraries I need (no need to install...)
library(tidyverse)

#' ## References
#' - [新谷ら 2015 プラスミドゲノミクス~全塩基配列解読済のプラスミドデータベースの整備 Genomics of Plasmids](https://www.jseb.jp/wordpress/wp-content/uploads/14-02-081.pdf)
#' - [Shintani et al. 2015 Front Microbiol. "Genomics of microbial plasmids: classification and identification based on replication and transfer systems and host taxonomy"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4379921/)
#' 
# Download File from the Internet
url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/plasmids.txt"
filename <- basename(url) # filename <- "plasmids.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Exploring and Transforming Dataframes
dim(d)
str(d) #glimpse(d) #tbl_df(d)

colnames(d) # Column Names
colnames(d)[1] <- "Organism"

# Return the First or Last Parts of an Object
head(d, n=2)
tail(d, n=1)

# Cross Tabulation and Table Creation
table(d$Kingdom)
# grepl returns a logical vector (match or not for each element of x)
pattern <- "Bacteria"
TF <- grepl(pattern=pattern, x=d$Kingdom, ignore.case=FALSE); summary(TF); d <- d[TF,]

table(d$Group)

# Object Summaries
summary(d)

# Exploring Data Visually
ggplot(data = d) + 
  geom_bar(mapping = aes(x = Group)) + 
  coord_flip()

## https://ggplot2.tidyverse.org/reference/geom_boxplot.html
ggplot(data = d, aes(x = Group, y = `GC%`)) +
  geom_boxplot() +
  coord_flip()

ggplot(data = d, aes(x = Group, y = `Size (Kb)`)) +
  geom_boxplot() +
  scale_y_log10() +
  coord_flip()

## https://ggplot2.tidyverse.org/reference/geom_histogram.html
ggplot(data = d, aes(x =`Size (Kb)`)) +
  geom_histogram(bins = 50) + scale_x_log10()

#' - [Rではじめるデータサイエンス](https://github.com/haruosuz/books/tree/master/r4ds)
#' - [R for Data Science](https://r4ds.had.co.nz/)
#'   - [3 Data visualisation](https://r4ds.had.co.nz/data-visualisation.html)
#'   - [7 Exploratory Data Analysis](https://r4ds.had.co.nz/exploratory-data-analysis.html)
#'      - [7.3 Variation](https://r4ds.had.co.nz/exploratory-data-analysis.html#variation)
#'   - [7.5 Covariation](https://r4ds.had.co.nz/exploratory-data-analysis.html#covariation)
#' ![](https://d33wubrfki0l68.cloudfront.net/153b9af53b33918353fda9b691ded68cd7f62f51/5b616/images/eda-boxplot.png)
#' 
sessionInfo()
Sys.time()
