#+ echo = TRUE
# clear the decks
rm(list = ls())

#+ message = TRUE
# libraries I need (no need to install...)
library(seqinr)

#' Suzuki et al. (2008) "Using Mahalanobis distance to compare genomic signatures between bacterial plasmids and chromosomes" https://doi.org/10.1093/nar/gkn753
#' https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#fna
# Make a vector containing NCBI accessions
ACCESSIONs <- c("NC_007530", "NC_007322", "NC_007323", "NC_002655", "NC_007414") # Bacillus anthracis # E.coli O157
#ACCESSIONs <- c("KM670336", "AP018710", "NZ_CP014764", "NZ_CP015073", "NZ_CP020602") # pSN1216-29 

# create a function to retrieve several nucleotide sequences from NCBI
retrieve_ncbi_fna <- function(ACCESSION) read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]

# Retrieve the sequences and store them in list variable "seqs"
fna.seqs <- lapply(ACCESSIONs, retrieve_ncbi_fna)

# write the sequences to a FASTA-format file
write.fasta(sequences=fna.seqs, names=getAnnot(fna.seqs), file.out="mySequences.fna")

# Reading sequence data
seqs <- read.fasta(file="mySequences.fna", seqtype="DNA", strip.desc=TRUE)

# 配列の数とアノテーションを確認する:  
length(seqs) # get the number of elements
unlist(getAnnot(seqs)) # get sequence annotations

# store the first element of the list object `seqs` in a variable `seq1`
seq1 <- seqs[[1]]

# https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#dna-sequence-statistics-1

# `summary` function to calculate DNA Sequence Statistics (length, composition, GC)
summary(seq1)

# dinucleotide count
count(seq = seq1, wordsize = 2)

# dinucleotide relative abundance
rho(seq = seq1, wordsize = 2)

# Creates a bar plot with a straight line
par(cex=0.7) # Set Graphical Parameters
barplot(sort(rho(seq = seq1, wordsize = 2)))
abline(h=1) # Add Straight Lines to a Plot

# Apply a Function over a List
#lapply(seqs, summary)
sapply(seqs, summary)

#getwd()
#list.files()

# dinucleotide relative abundance
myrho <- sapply(seqs, rho, wordsize = 2)

# Draw a Heat Map
heatmap(myrho, margins=c(7, 2), cexCol=0.9, scale="none", col=rev(gray.colors(12)))

#' - https://github.com/haruosuz/DS4GD/blob/master/2017/hclust.md#heat-map
#' 
# for loop to carry out the same command several times
par(cex=0.9) # Set Graphical Parameters
for(k in 2:4){
  myrho <- sapply(seqs, rho, wordsize = k)
  #write.table(data.frame(myrho), file=paste0("Rtable.rho.kmer",k,".txt"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
  write.csv(data.frame(myrho), file=paste0("Rtable.rho.kmer",k,".csv"), quote=TRUE, row.names=TRUE)
  # cluster analysis
  hc <- hclust(as.dist(1-cor(myrho))); #plot(hc)
  # heatmap
  heatmap(t(myrho), Rowv=as.dendrogram(hc), cexCol=1/k, col=rev(gray.colors(12)))
}

unlist(getAnnot(seqs)) # get sequence annotations

#' 
sessionInfo()
Sys.time()

