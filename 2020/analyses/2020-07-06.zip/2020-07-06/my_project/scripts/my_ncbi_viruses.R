#' # viruses.txt
#' Viral genome sequencing projects  
#' This report includes only data represented in the RefSeq dataset. 

# clear the decks
rm(list = ls())

#' ## References
#' - [NCBI Genome List](https://github.com/haruosuz/DS4GD/blob/master/2020/CaseStudy.md#ncbi-genome-list)
#' - https://www.ncbi.nlm.nih.gov/genome/browse
#' - ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/
#' - ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

# Download File from the Internet
url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/viruses.txt"
filename <- basename(url) # filename <- "viruses.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Exploring and Transforming Dataframes
dim(d)
str(d)

colnames(d) # Column Names

# Return the First or Last Parts of an Object
head(d, n=2)
tail(d, n=1)

# Cross Tabulation and Table Creation
table(d$Group)
#table(d$SubGroup)

# grepl returns a logical vector (match or not for each element of x)
pattern <-"dengue"
TF <- grepl(pattern=pattern, x=d$`#Organism/Name`, ignore.case=TRUE); summary(TF)
d <- d[TF,]

# Exploring Data Visually
x <- "Size (Kb)" # Total length of nucleotide sequence
y <- "GC%" # Percent of nitrogenous bases (guanine or cytosine)
#y <- "Genes" # Number of Genes
plot(d[,x], d[,y], xlab = x, ylab = y)
text(d[,x], d[,y], labels=d[,1])
cor(d[,x], d[,y], method="spearman")

# Exporting Data
#write.table(d, file="table.txt", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
write.csv(d, file="table.csv", quote=TRUE, row.names=TRUE)
#getwd()
#dir()
