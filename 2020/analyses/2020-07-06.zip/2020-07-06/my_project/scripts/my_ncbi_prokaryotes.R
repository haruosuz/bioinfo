#' # prokaryotes.txt
#' Prokaryotic genome sequencing projects 
#' excluding projects that represent only plasmids
#' 
#' - ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/
#' - ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

#+ echo = FALSE
# clear the decks
rm(list = ls())

#+ message = FALSE
# libraries I need (no need to install...)
library(tidyverse)

# Download File from the Internet
url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/prokaryotes.txt" # 77MB
filename <- basename(url) # filename <- "prokaryotes.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Exploring and Transforming Dataframes
dim(d)
str(d) #glimpse(d) #tbl_df(d)

colnames(d) # Column Names
colnames(d)[1] <- "Organism"

# Return the First or Last Parts of an Object
head(d, n=2)
tail(d, n=1)

# Status
table(d$Status)
TF <- grepl(pattern="Complete", x=d$Status, ignore.case=TRUE); summary(TF); d <- d[TF,]

# Reference
table(d$Reference) # REFR REPR
#TF <- grepl(pattern="REFR|REPR", x=d$Reference, ignore.case=TRUE); sum(TF); d <- d[TF,]

# Object Summaries
summary(d)

# grepl returns a logical vector (match or not for each element of x)
OrganismName <- "^['\\[]"
#OrganismName <- "Streptomyces lividans"; #OrganismName <- "Francisella"
TF <- grepl(pattern=OrganismName, x=d[,1], ignore.case=FALSE); summary(TF); d[TF,1]; d <- d[!TF,]

# Exploring Data Visually
ggplot(d, aes(x = `Size (Mb)`, y = `GC%`)) + geom_point(size = 0.1)

#' ![](https://www.ncbi.nlm.nih.gov/pmc/articles/instance/5989581/bin/mgen-4-168-f001.jpg)
#' 
#' - [文字列の分割: str_split()](https://kazutan.github.io/kazutanR/stringr-intro.html)
ss <- str_split(string=d[,1], pattern=" ", n=3, simplify=TRUE)
head(ss)
d$Genus <- ss[,1]
d$Species <- apply(ss[,1:2], 1, paste0, collapse=" ")

#' - [R for Data Science](https://r4ds.had.co.nz/)
#'   - [5 Data transformation](https://r4ds.had.co.nz/transform.html#grouped-summaries-with-summarise)
#'      - [5.6 Grouped summaries with summarise()](https://r4ds.had.co.nz/transform.html#grouped-summaries-with-summarise)
by_genus <- d %>% 
  group_by (Genus) %>%
  summarise(
    n = n(),
    meanSize = mean(`Size (Mb)`),
    meanGC = mean(`GC%`)) %>%
  arrange(desc(meanGC))
# https://r4ds.had.co.nz/tibbles.html#printing

TF <- grepl(pattern="Comamonas|Pseudomonas", x=by_genus$Genus); summary(TF); by_genus[TF,]

#' - [Write a data frame to a delimited file](https://readr.tidyverse.org/reference/write_delim.html)
write_csv(by_genus, "Rtable.csv.gz")
#write_tsv(by_genus, "Rtable.tsv.gz")
#' - [readr — 高速で柔軟なテーブル読み込み](https://heavywatal.github.io/rstats/readr.html)
#read_csv("Rtable.csv.gz")
#read_tsv("Rtable.tsv.gz")

#getwd()
#list.files()

sessionInfo()
Sys.time()
