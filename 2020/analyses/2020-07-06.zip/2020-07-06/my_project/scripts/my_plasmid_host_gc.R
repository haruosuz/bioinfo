#' # GC% comparison between plasmids and their hosts
#' ## References
#' - Shintani M., Suzuki H. (2019) Plasmids and Their Hosts. In: Nishida H., Oshima T. (eds) DNA Traffic in the Environment. Springer, Singapore. DOI: https://doi.org/10.1007/978-981-13-3411-5_6
#' 
#+ echo = TRUE
# clear the decks
rm(list = ls())

#+ message = FALSE
# libraries I need (no need to install...)
library(tidyverse)

# Loading Data into R
# plasmid
filename <- "plasmids.txt"
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)
dim(d)
head(d, n=2)
head(d$RefSeq, n=2)
# grepl returns a logical vector (match or not for each element of x)
TF <- grepl(pattern="NC_", x=d$RefSeq); summary(TF); d <- d[TF,]
table(d$Group)
TF <- grepl(pattern="Proteobacteria", x=d$Group); summary(TF); d <- d[TF,]
table(d$SubGroup)
TF <- grepl(pattern="Betaproteobacteria", x=d$SubGroup); summary(TF); d <- d[TF,]
dp <- d

# host
filename <- "prokaryotes.txt"
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)
dim(d)
head(d, n=2)
head(d$Replicons, n=5)
# grepl returns a logical vector (match or not for each element of x)
TF <- grepl(pattern="plasmid", x=d$Replicons, ignore.case=FALSE); summary(TF); d <- d[TF,]
dh <- d

# Host_GC
#x <- dp$RefSeq[3]; TF <- grepl(pattern=x, x=dh$Replicons); summary(TF); dh$`GC%`[TF]; if(sum(TF)){ dh$`GC%`[TF] } else { NA }
system.time(dp$Host_GC <- sapply(dp$RefSeq, function(x){ TF <- grepl(pattern=x, x=dh$Replicons); if(sum(TF)){ dh$`GC%`[TF] } else { NA } }))

# geom_point
ggplot(dp, aes(x = Host_GC, y = `GC%`)) + 
  geom_point(size = 0.5) + 
  geom_abline(intercept = 0, slope = 1) +
  xlab("Host GC%") + 
  ylab("Plasmid GC%") + 
  theme_bw()

#' Fig. Plot of G+C contents (GC%) between plasmids and their corresponding hosts.
#' Each point represents a plasmid-host pair.
#' The y-axis indicates the G+C content of plasmids (plasmid GC%) and the x-axis indicates the G+C content of hosts (host GC%), 
#' retrieved from the National Center for Biotechnology Information (NCBI) genome list (ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/).

ggsave("Rplot_plasmid_host_GC.png")

sessionInfo()
Sys.time()

