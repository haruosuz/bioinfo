# https://github.com/haruosuz/introBI/blob/master/2017/CaseStudy.md#ncbi-genome-list
# https://github.com/haruosuz/introBI/blob/master/2017/CaseStudy.md#working-with-data-in-r-1
# ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/viruses.txt"
filename <- basename(url) # filename <- "viruses.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# grep(pattern, x) returns the positions of all elements in x that match pattern
TF <- grepl(pattern="Complete", x=d$Status, ignore.case=TRUE); sum(TF); d <- d[TF,]

pattern="ebolavirus"
pattern="Bovine adenovirus"
pattern="Dengue virus"
pattern="Variola virus"
pattern="Abaca bunchy top virus"
TF <- grepl(pattern=pattern, x=d$`#Organism/Name`, ignore.case=FALSE); sum(TF); d <- d[TF,]

# Exploring and Transforming Dataframes
dim(d)
colnames(d)
head(d, n=3)
tail(d, n=4)
?NA

# Ordering data
d[order(d$`Size (Kb)`), c("#Organism/Name", "Size (Kb)", "GC%", "Host")] # "Segmemts"

# Exploring Data Visually
x <- "Size (Kb)" # Total length of nucleotide sequence
y <- "GC%" # Percent of nitrogenous bases (guanine or cytosine)
plot(d[,x], d[,y], xlab = x, ylab = y)
#text(d[,x], d[,y], labels=d[,1])

# Exporting Data
write.table(d, file="table.txt", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
getwd()
dir()


