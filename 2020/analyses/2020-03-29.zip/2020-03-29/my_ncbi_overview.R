# ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/overview.txt" # 4.1 MB
filename <- basename(url) # filename <- "overview.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# grep(pattern, x) returns the positions of all elements in x that match pattern
pattern="coronavirus"
pattern="^Arabidopsis thaliana$|^Danio rerio$|^Drosophila melanogaster$|^Escherichia coli$|^Homo sapiens$|^Mus musculus$|^Oryza sativa$|^Saccharomyces cerevisiae$"
TF <- grepl(pattern=pattern, x=d[,1], ignore.case=TRUE); sum(TF); d <- d[TF,]

# Exploring and Transforming Dataframes
dim(d)
colnames(d)
head(d, n=3)
tail(d, n=4)
?NA

# Ordering data
d[order(d$`Size (Mb)`), c("#Organism/Name", "Size (Mb)", "Chrs")]

# Exploring Data Visually
x <- "Size (Mb)" # Estimated genome size
y <- "Chrs" # Number of chromosomes
plot(d[,x], d[,y], xlab = x, ylab = y)
#text(d[,x], d[,y], labels=d[,1])
cor(d[,x], d[,y], method="spearman")

# Exporting Data
write.table(d, file="table.txt", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
getwd()
dir()

