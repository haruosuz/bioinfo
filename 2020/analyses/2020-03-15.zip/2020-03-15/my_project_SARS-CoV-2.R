# https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1

# Cmd/Ctrl + Enter

#install.packages("seqinr")
library("seqinr") # read.fasta # write.fasta # GC

# https://www.ncbi.nlm.nih.gov/genome/86693
# Severe acute respiratory syndrome coronavirus 2
ACCESSION <- "NC_045512.2" # RefSeq
#ACCESSION <- "MN908947.3" # INSDC
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")

# Retrieving a DNA sequence from NCBI
seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)

# Writing the sequences to a FASTA-format file
write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fna"))

# Get the 1st sequence
seq1 <- seqs[[1]]
seq1[1:10] # The first 10 nucleotides of the sequence
head(seq1, 10) # The first 10 nucleotides of the sequence
tail(seq1, 10) # The last 10 nucleotides of the sequence

# Length of a DNA sequence
length(seq1)

# Base composition of a DNA sequence
table(seq1)

# GC Content of DNA
GC(seq1)

# length # composition # GC
summary(seq1)

