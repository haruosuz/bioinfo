# ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/viruses.txt"
filename <- basename(url) # filename <- "viruses.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# grepl returns a logical vector (match or not for each element of x)
pattern <- "Severe acute respiratory syndrome-related|Human betacoronavirus|^[^ ]+ coronavirus$"
#pattern <- "Severe acute respiratory syndrome|Human betacoronavirus|^[^ ]+ coronavirus$"
#pattern <- "coronavirus"
# NC_019843 Middle East respiratory syndrome-related coronavirus (MERS-CoV) # JX869059 Human betacoronavirus 2c EMC/2012
TF <- grepl(pattern=pattern, x=d$`#Organism/Name`, ignore.case=FALSE); summary(TF); d$`#Organism/Name`[TF]

d <- d[TF,]

# Exploring and Transforming Dataframes
dim(d)
colnames(d)
head(d, n=2)
tail(d, n=1)
summary(d[c(7,8,11,12)])

# Ordering data
d[order(d$`Size (Kb)`), c("#Organism/Name", "Size (Kb)", "GC%", "Genes")] # "Host", "Segmemts"

# Exporting Data
write.table(d, file="table.txt", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
getwd()
dir()

# Refseq and INSDC Chromosome accessions
d$Refseq <- sub(pattern="( Unknown:)*((.+)\\.[0-9]\\/)*(.+)\\.[0-9]", replacement="\\3", d$`Segmemts`)
d$INSDC <- sub(pattern="( Unknown:)*((.+)\\.[0-9]\\/)*(.+)\\.[0-9]", replacement="\\4", d$`Segmemts`)

library("seqinr")
# create a function to retrieve several nucleotide sequences from NCBI
retrieve_ncbi_fna <- function(ACCESSION) read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]

# https://github.com/haruosuz/r4bioinfo/tree/master/R_Avril_Coghlan#retrieving-genome-sequence-data-using-seqinr
# Retrieve the sequences and store them in list variable "seqs"
#seqs <- lapply(d$Refseq, retrieve_ncbi_fna)
seqs <- lapply(d$INSDC, retrieve_ncbi_fna)

# https://github.com/haruosuz/r4bioinfo/tree/master/R_Avril_Coghlan#writing-sequence-data-out-as-a-fasta-file
# write the sequences to a FASTA-format file
write.fasta(sequences=seqs, names=getAnnot(seqs), file.out="mySequences.fna")

# https://github.com/haruosuz/r4bioinfo/tree/master/R_Avril_Coghlan#length-of-a-dna-sequence
length(seqs)
unlist(getAnnot(seqs)) # get sequence annotations
sapply(seqs, summary) # Apply a Function over a List

# https://github.com/haruosuz/r4bioinfo/tree/master/R_Avril_Coghlan#dna-words
# Count oligomers (monomer/dimer/trimer/etc)
# Apply a Function over a List
mycount <- sapply(seqs, count, wordsize = 2)

# Column Names
colnames(mycount)
colnames(mycount) <- sapply(getAnnot(seqs),function(x) paste0(substr(x=unlist(strsplit(x,split=" ")),1,1),collapse=""))

# Draw a Heat Map
heatmap(mycount, margins=c(7, 2), cexCol=0.9, scale="none", col=rev(gray.colors(12)))

unlist(getAnnot(seqs)) # get sequence annotations

# https://en.wikipedia.org/wiki/Polyadenylation
# https://twitter.com/cosmos4u/status/1234503992501252096
# https://bioinformatics.stackexchange.com/questions/11227/why-does-the-wuhan-coronavirus-genome-end-in-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
sapply(seqs, function(x) c2s(tail(x,35)))
sapply(seqs, function(x) table(tail(x,35)))



