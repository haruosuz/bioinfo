# ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/viruses.txt"
filename <- basename(url) # filename <- "viruses.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Exploring and Transforming Dataframes
dim(d)
head(d, n=2)
tail(d, n=1)
colnames(d)

# Cross Tabulation and Table Creation
table(d$`Status`)
table(d$`Group`)
sort(table(d$`Group`))
table(d$`SubGroup`)
sort(table(d$`Host`))

# grepl returns a logical vector (match or not for each element of x)
TF <- grepl(pattern="Complete", x=d$Status, ignore.case=TRUE); sum(TF); d <- d[TF,]

pattern <- "ebola"
TF <- grepl(pattern=pattern, x=d$`#Organism/Name`, ignore.case=TRUE); sum(TF); 
d[TF, c("#Organism/Name", "Group", "SubGroup")]

pattern <- "Filoviridae"
TF <- grepl(pattern=pattern, x=d$`SubGroup`, ignore.case=FALSE); sum(TF); 
d[TF, c("#Organism/Name", "Group", "SubGroup")]

d <- d[TF,]

# Ordering data
x <- "Size (Kb)" # Total length of nucleotide sequence
x <- "GC%" # Percent of nitrogenous bases (guanine or cytosine)
d[order(d[,x]), c("#Organism/Name", "Size (Kb)", "GC%", "Genes")]

# Exploring Data Visually
x <- "Size (Kb)" # Total length of nucleotide sequence
y <- "GC%" # Percent of nitrogenous bases (guanine or cytosine)
#y <- "Genes" # Number of Genes
plot(d[,x], d[,y], xlab = x, ylab = y)
#text(d[,x], d[,y], labels=d[,1])
#cor(d[,x], d[,y], method="spearman")

# Exporting Data
write.table(d, file="table.txt", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
getwd()
dir()
