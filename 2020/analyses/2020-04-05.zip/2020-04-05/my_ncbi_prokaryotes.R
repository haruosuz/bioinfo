# ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/prokaryotes.txt" # 71.8 MB
filename <- basename(url) # filename <- "prokaryotes.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Exploring and Transforming Dataframes
dim(d)
head(d, n=2)
colnames(d) # "Group" "SubGroup" "Status"

# Cross Tabulation and Table Creation
table(d$`Status`)

# grepl returns a logical vector (match or not for each element of x)
TF <- grepl(pattern="Complete", x=d$Status, ignore.case=TRUE); summary(TF); d <- d[TF,]

# Cross Tabulation and Table Creation
table(d$`Group`)
sort(table(d$`Group`))
sort(table(d$`SubGroup`))

# grepl returns a logical vector (match or not for each element of x)
pattern <- "Proteobacteria"
TF <- grepl(pattern=pattern, x=d$`Group`, ignore.case=FALSE); summary(TF)

pattern <- "Alphaproteobacteria"
TF <- grepl(pattern=pattern, x=d$`SubGroup`, ignore.case=FALSE); summary(TF)

summary(d[TF,])

# Exploring Data Visually
x <- "Size (Mb)" # Total length of DNA
y <- "GC%" # Percent of nitrogenous bases (guanine or cytosine)
#y <- "Genes" # Number of Genes
plot(d[TF,x], d[TF,y], xlab = x, ylab = y)

# Exporting Data
write.table(d[TF,], file="table.txt", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
getwd()
dir()
