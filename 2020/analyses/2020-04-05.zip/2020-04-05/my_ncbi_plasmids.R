# ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README

url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/plasmids.txt"
filename <- basename(url) # filename <- "plasmids.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Exploring and Transforming Dataframes
dim(d)
head(d, n=2)
tail(d, n=1)
colnames(d)

# Cross Tabulation and Table Creation
table(d$`Kingdom`)

# grepl returns a logical vector (match or not for each element of x)
pattern <- "Viruses"
TF <- grepl(pattern=pattern, x=d$`Kingdom`, ignore.case=FALSE); summary(TF)
d[TF,]
# https://www.ncbi.nlm.nih.gov/search/all/?term=KF664581.1

# Exporting Data
write.table(d[TF,], file="table.txt", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
getwd()
dir()