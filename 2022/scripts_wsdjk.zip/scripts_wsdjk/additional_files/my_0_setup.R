# Haruo Suzuki
# 2023-06-17
# This script is for setting up the environment, including package installation and data import into R

#' - https://github.com/haruosuz/books/tree/master/r4all
#' 
#' ## 1.8 Important functionality: packages
options(repos="https://cran.ism.ac.jp/")

# Install R packages
install.packages("tidyverse")
install.packages("readxl")
install.packages("psych")
install.packages("GGally")
install.packages("seqinr")

# Load R packages
library(tidyverse)
library(readxl)
library(psych)
library(GGally)
library(seqinr)

#' ## 2.2 Getting your data into R
#' - http://r4all.org/books/datasets/

# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url)
if(!file.exists(filename)){ download.file(url = url, destfile = filename); unzip(zipfile = filename); }

# List the Files in a Directory/Folder
list.files(path = "datasets-master")
