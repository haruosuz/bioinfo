# Haruo Suzuki
# 2025-04-27
# This script is for the analysis of 
# the number of deaths due to COVID-19 "COVID-deaths.csv".

# Clear R's environment
rm(list = ls())

# Load R packages
library(tidyverse)

# Read the COVID-19 deaths data
URL <- "https://okumuralab.org/~okumura/python/data/COVID-deaths.csv"
df <- read_csv(URL, col_types = cols(month = col_character()))

# Plot the data with smaller English font size
df %>%
  ggplot(aes(x = month, y = deaths)) +
  geom_col(width = 0.8) +  # Width between 0 and 1 looks better
  labs(x = "Month", y = "Number of deaths") +
  theme(
    axis.text.x = element_text(size = 9, angle = 90, hjust = 1),  # Set font size for x-axis tick labels
    axis.text.y = element_text(size = 9)                          # Set font size for y-axis tick labels
  )

#' # References
#' - 2025-04-27 https://okumuralab.org/~okumura/python/COVID-deaths.html
#' COVID-19による死者数
#'   - https://x.com/h_okumura/status/1916409620656259324
#' - https://www.yomiuri.co.jp/local/kyushu/news/20250508-OYTNT50018/
#' 新型コロナ「５類」移行後の死者は５万人超える…専門家「今後も流行を繰り返す可能性は高い」
#' - https://www3.nhk.or.jp/news/special/infection/dashboard/
#' 約20種類の感染症 感染者数の推移・全国比較 最新ニュース - NHK
#' - https://mainichi.jp/english/covid19
#' Coronavirus (COVID-19) infections in Japan - The Mainichi
#' - https://moderna-epi-report.jp/
#' 新型コロナ・季節性インフルエンザ・RSウイルス リアルタイム流行・疫学情報
#' - https://x.com/metacovid19
#' 
