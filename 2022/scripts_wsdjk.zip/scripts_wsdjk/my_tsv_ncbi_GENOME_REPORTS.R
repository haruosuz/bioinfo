# Haruo Suzuki
# 2024-06-15
# This script is for the analysis of NCBI GENOME_REPORTS

# Clear R's environment
rm(list = ls())

# Load R packages
library(tidyverse)
#install.packages("psych")
library(psych) # pairs.panels
#install.packages("GGally")
library(GGally) # ggpairs

#' # NCBI GENOME_REPORTS
#' - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/
#' On this page, right click on the link to the file (eukaryotes.txt, overview.txt, plasmids.txt, prokaryotes.txt, viruses.txt), and select "Copy Link Address".
#'   - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/eukaryotes.txt"
#url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/overview.txt"
#url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/plasmids.txt"
#url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/prokaryotes.txt"
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/viruses.txt"
filename <- basename(url); filename
# Set Organism/Name to include and exclude
if (filename == "eukaryotes.txt") { includeOrganism <- "Paramecium|Tetrahymena"; excludeOrganism <- "Midi-chlorian" }
if (filename == "overview.txt") { includeOrganism <- "E.*coli|^Saccharomyces"; excludeOrganism <- "Midi-chlorian" }
if (filename == "plasmids.txt") { includeOrganism <- "Wolbachia"; excludeOrganism <- "Midi-chlorian" }
if (filename == "prokaryotes.txt") { includeOrganism <- "Holospora"; excludeOrganism <- "Midi-chlorian" }
if (filename == "viruses.txt") { includeOrganism <- "Dengue virus|Zika virus"; excludeOrganism <- "Midi-chlorian" }
includeOrganism
excludeOrganism

# Download File from the Internet
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Check out the data
dim(d)      # Display the dimensions (number of rows and columns) of the data frame
colnames(d) # Print the column names of the data frame

#table(d$Group)
#TF <- grepl(pattern="Aquificota", x=d$`Group`); summary(TF); gsub("\\(|\\)", ".", paste0(d$`#Organism/Name`[TF], collapse="$|^"))

#table(d$SubGroup)
#TF <- grepl(pattern="Aquificae", x=d$`SubGroup`); summary(TF); gsub("\\(|\\)", ".", paste0(d$`#Organism/Name`[TF], collapse="$|^"))

# `grepl` returns a logical vector (match or not for each element of x)
myd <- d
TF <- grepl(pattern=includeOrganism, x=myd$`#Organism/Name`, ignore.case=TRUE); summary(TF); myd <- myd[TF,]
TF <- grepl(pattern=excludeOrganism, x=myd$`#Organism/Name`, ignore.case=TRUE); summary(TF); myd <- myd[!TF,]

# Status: "Complete Genome", "Chromosome", "Contig", "Scaffold"
#table(myd$Status); TF <- grepl(pattern="Complete", x=myd$`Status`); summary(TF); myd <- myd[TF,]
dim(myd)

# Display the first and last few rows of the data frame
head(myd, n = 2)
tail(myd, n = 2)

# Sory by Size
TF <- grepl(pattern = "Size", x = colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol; myd <- myd %>% arrange(desc(!!sym(mycol)))

# summary plot
TF <- grepl(pattern = "Size|Chrs|GC|Gene", x = colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
myd %>% select(mycol) %>% summary
myd %>% select(mycol) %>% plot
#myd %>% select(mycol) %>% pairs.panels(smooth=FALSE, density=FALSE, ellipses=FALSE)
#myd %>% select(mycol) %>% ggpairs

# ggplot
colnames(myd)
if (grepl(pattern="overview|eukaryotes|prokaryotes", x=filename)) { myx <- "Size (Mb)"; myy <- "Genes"; }
if (grepl(pattern="plasmids|viruses", x=filename)) { myx <- "Size (Kb)"; myy <- "GC%"; }
ggplot(myd, aes(x = !!sym(myx), y = !!sym(myy))) + geom_point()
ggplot(myd, aes(x = !!sym(myx))) + geom_histogram(bins = 5)

# Export
write_csv(myd, paste0("my.", filename,".csv"))
#write_tsv(myd, paste0("my.", filename,".tsv"))

#View(myd) # Uncommenting `View()` may cause issues with [Compile Report].
#getwd()      # get the current working directory
#list.files() # list files in the current working directory
sessionInfo() # get information about the R session
Sys.time()    # Print the current system time

#' # References
#' - https://en.wikipedia.org/wiki/Taxonomic_rank
#' - https://www.ncbi.nlm.nih.gov/datasets/
#' - http://www.ncbi.nlm.nih.gov/genome/browse/
#' - https://github.com/haruosuz/introBI
#'   - https://github.com/haruosuz/introBI/blob/main/CaseStudy.md
#' - https://github.com/haruosuz/DS4GD/
#'   - https://github.com/haruosuz/DS4GD/blob/master/CaseStudy.md
#' - https://doi.org/10.7875/togotv.2023.087
#' Posit Cloud (旧：RStudio Cloud) を用いて生物配列データ解析に取り組む @ AJACSオンライン18
#' 
