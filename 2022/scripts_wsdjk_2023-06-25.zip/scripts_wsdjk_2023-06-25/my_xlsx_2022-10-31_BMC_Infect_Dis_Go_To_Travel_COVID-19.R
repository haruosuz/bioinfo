# Haruo Suzuki
# 2023-06-24
# This script is for the analysis of "Go To Travel campaign and the geographic spread of COVID-19 in Japan"

# Loading Packages
#options(repos="https://cran.ism.ac.jp/")
#install.packages("readxl")
library(readxl)
library(tidyverse)
library(psych) # pairs.panels
library(GGally) # ggpairs

# Clear R's brain
rm(list = ls())

#' # Go To Travel campaign and the geographic spread of COVID-19 in Japan
#' BMC Infect Dis. 2022 Oct 31;22(1):808. doi: 10.1186/s12879-022-07799-0.
#' Asami Anzai 1, Sung-Mok Jung 1, Hiroshi Nishiura 2
#' - https://twitter.com/nishiurah/status/1665673446985187329
#' - https://pubmed.ncbi.nlm.nih.gov/36316657/
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9619015/
#' 
#' Supplementary Materials
#' Additional file 1. Number of prefectures that exceeded the threshold number of cases per 100,000 persons.
#' 12879_2022_7799_MOESM1_ESM.xlsx (13K)
# Download File from the Internet
url <- ""
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9619015/bin/12879_2022_7799_MOESM1_ESM.xlsx"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

excel_sheets(path=filename) # List all sheets in an excel spreadsheet
which(excel_sheets(path=filename) == "AdditionalData2")
d <- read_excel(path=filename, sheet=1, skip=0) # Read xls and xlsx files

# Check out the data
dim(d) # Display the dimensions (number of rows and columns) of the data frame
colnames(d) # Print the column names of the data frame
str(d)
#View(d)

# Export
write_csv(d, paste0("my.", filename,".csv"))
#write_tsv(d, paste0("my.", filename,".tsv"))

# Statistics
summary(d)
d %>% pairs.panels
d %>% ggpairs

#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9619015/figure/Fig2/
#' 

sessionInfo()
Sys.time()
