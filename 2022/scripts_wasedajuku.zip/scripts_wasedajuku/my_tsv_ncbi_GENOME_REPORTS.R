# Haruo Suzuki
# 2023-05-14
# This script is for the analysis of NCBI GENOME_REPORTS

# Clear R's brain
rm(list = ls())

# libraries I need (no need to install...)
library(tidyverse)

#' # NCBI GENOME_REPORTS
#' - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/
#' On this page, right click on the link to the file (*overview.txt*), and select "Copy Link Address".s
# Download File from the Internet
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/overview.txt"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# check out the data
dim(d)
table(d$Kingdom)
head(d, n=2)
tail(d, n=2)
colnames(d)

# grepl returns a logical vector (match or not for each element of x)
Organism_Name <- "Measles morbillivirus"
TF <- grepl(pattern=Organism_Name, x=d[,1], ignore.case=TRUE); summary(TF)
d[TF,]

#getwd()
#list.files()
#sessionInfo()
Sys.time()

#' # References
#' - https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ncbi-genome-list
#' - https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list
#' 
