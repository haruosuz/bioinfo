# Haruo Suzuki
# 2023-05-20
# This script is for the analysis of NCBI GENOME_REPORTS

# Clear R's brain
rm(list = ls())

# libraries I need (no need to install...)
library(tidyverse)

#' # NCBI GENOME_REPORTS
#' - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/
#' On this page, right click on the link to the file (*overview.txt*), and select "Copy Link Address".
#' 
# Download File from the Internet
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/overview.txt"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# check out the data
dim(d)
colnames(d)
head(d, n=2)
tail(d, n=2)
table(d$Kingdom)

# grepl returns a logical vector (match or not for each element of x)
myOrganism <- "Measles morbillivirus"
myOrganism <- "Influenza"
TF <- grepl(pattern=myOrganism, x=d$`#Organism/Name`); summary(TF)
#d[TF,]
#table(d$`#Organism/Name`[TF])
table(d$`SubGroup`[TF])
mySubGroup <- "Paramyxoviridae" # "Measles morbillivirus"
mySubGroup <- "Orthomyxoviridae" # "Influenza"
TF <- grepl(pattern=mySubGroup, x=d$`SubGroup`); summary(TF)
summary(d$`Size (Mb)`[TF])
hist(d$`Size (Mb)`[TF])
#getwd()
#list.files()
#sessionInfo()
Sys.time()

#' # References
#' - https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ncbi-genome-list
#' - https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list
#' 
