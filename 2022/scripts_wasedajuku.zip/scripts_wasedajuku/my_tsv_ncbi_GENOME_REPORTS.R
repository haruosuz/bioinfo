# Haruo Suzuki
# 2023-05-21
# This script is for the analysis of NCBI GENOME_REPORTS

# Clear R's environment
rm(list = ls())

# Load required libraries (no need to install...)
#library(tidyverse)

#' # NCBI GENOME_REPORTS
#' - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/
#' On this page, right click on the link to the file (*overview.txt*), and select "Copy Link Address".
#' 
# Download File from the Internet
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/overview.txt"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)


# Check out the data
dim(d)           # Display the dimensions (number of rows and columns) of the data frame `d`
colnames(d)      # Print the column names of the data frame `d`
head(d, n = 2)   # Display the first few rows of the data frame `d`
tail(d, n = 2)   # Display the last few rows of the data frame `d`
table(d$Kingdom) # Create a table showing the count of each `Kingdom` in the data

# `grepl` returns a logical vector (match or not for each element of x)
# Organism/Name
myOrganism <- "Measles morbillivirus" # Set Organism/Name of interest
myOrganism <- "Influenza"             # Set Organism/Name of interest
TF <- grepl(pattern = myOrganism, x = d$`#Organism/Name`)  # Check if the `#Organism/Name` matches pattern in `myOrganism`
summary(TF)      # Display the number of matches or non-matches
d[TF,]          # Uncomment to display the rows where there is a match
#table(d$`#Organism/Name`[TF]) # Uncomment to create a table of counts for matched organism names
table(d$`SubGroup`[TF]) # Create a table showing the count of each subgroup for matched organism names
# SubGroup
mySubGroup <- "Paramyxoviridae"  # Set SubGroup of interest
mySubGroup <- "Orthomyxoviridae" # Set SubGroup of interest
TF <- grepl(pattern = mySubGroup, x = d$`SubGroup`) # Check if the `SubGroup` matches pattern in `mySubGroup`
summary(TF)      # Display the number of matches or non-matches
summary(d$`Size (Mb)`[TF])  # Summarize the value `Size (Mb)` for matched `SubGroup`
hist(d$`Size (Mb)`[TF])  # Create a histogram of the value `Size (Mb)` for matched `SubGroup`

#getwd()        # Uncomment to get the current working directory
#list.files()   # Uncomment to list files in the current working directory
#sessionInfo()  # Uncomment to get information about the R session
Sys.time()      # Print the current system time

#' # References
#' - https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ncbi-genome-list
#' - https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list
#' - https://en.wikipedia.org/wiki/Taxonomic_rank
#' ![https://www.biologyonline.com/dictionary/taxonomy](https://www.biologyonline.com/wp-content/uploads/2020/09/taxonomy-definition-and-example-diagram-768x432.jpg)
#' 
#' 
