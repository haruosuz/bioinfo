#' # seqinr
#' - https://seqinr.r-forge.r-project.org/
#' Before reading the full manual, a short introduction to seqinr is available here
#' - August 3, 2017 https://seqinr.r-forge.r-project.org/src/mainmatter/introduction.pdf
#' 
#' ## 1.5 Getting started
# install the seqinr package
options(repos="https://cran.ism.ac.jp/")
#install.packages("seqinr")
# load the seqinR package with:
library("seqinr")
lseqinr()[1:9]

help(aaa)
example(aaa)

help(AAstat)
example(AAstat)

# Create tests
testseq <- s2c("acgt")
testseq
# The first 2 nucleotides of the sequence
head(testseq, 2) 
# The last 10 nucleotides of the sequence
tail(testseq, 2)
# Length of a DNA sequence
length(testseq)
# Base composition of a DNA sequence
table(testseq)
# GC Content of DNA
GC(testseq)
# DNA words
count(seq = testseq, wordsize = 2)

#' # References
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_seqinR
#' - https://github.com/haruosuz/DS4GD/blob/master/2023-04/README.md
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md
#' 
