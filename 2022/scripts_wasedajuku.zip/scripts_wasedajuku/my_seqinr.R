# Haruo Suzuki
# 2023-05-21
# This script is for DNA sequence analysis using the seqinr package

# Clear R's environment
rm(list = ls())

#' - https://seqinr.r-forge.r-project.org/
#' Before reading the full manual, a short introduction to seqinr is available here
#' - August 3, 2017 https://seqinr.r-forge.r-project.org/src/mainmatter/introduction.pdf

# Install the seqinr package
#options(repos = "https://cran.ism.ac.jp/")
#install.packages("seqinr")

# Load the seqinR package
library("seqinr")

# Create a mock DNA sequence
myseq <- s2c("acgt")
# Display the DNA sequence
myseq
# Calculate the length of the DNA sequence
length(myseq)
# Calculate the base composition of the DNA sequence
table(myseq)
# Calculate the GC content of the DNA sequence
GC(myseq)

#' # References
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_seqinR
#' - https://github.com/haruosuz/DS4GD/blob/master/2023-04/README.md
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md
#' 
