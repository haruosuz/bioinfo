# Haruo Suzuki
# 2022-05-29
# This script is for the analysis of TEMPURA: Database of Growth TEMPeratures of Usual and RAre Prokaryotes.

# Loading Packages
library(tidyverse)

# Clear R's brain
rm(list = ls())

#' # TEMPURA: Database of Growth TEMPeratures of Usual and RAre Prokaryotes
#' 
#' - https://www.jstage.jst.go.jp/article/jsme2/35/3/35_ME20074/_article
#' - http://togodb.org/db/tempura
# Download File from the Internet
url <- "http://togodb.org/release/200617_TEMPURA.csv"
filename <- basename(url) # filename <- "200617_TEMPURA.csv"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.csv(file=filename, check.names=FALSE, stringsAsFactors=TRUE)

# Checking Data
dim(d)
colnames(d)
head(d, n=1)
tail(d, n=1)
#str(d)
#glimpse(d)
summary(d)

sessionInfo()
Sys.time()
