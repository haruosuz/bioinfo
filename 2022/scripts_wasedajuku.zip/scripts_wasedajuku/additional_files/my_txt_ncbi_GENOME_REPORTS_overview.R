# Haruo Suzuki
# 2022-06-26
# This script is for NCBI GENOME_REPORTS overview.txt

# Clear R's brain
rm(list = ls())

# libraries I need (no need to install...)
library(tidyverse)

#' # NCBI GENOME_REPORTS
#' - ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS
#' - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README
# Download File from the Internet
url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/overview.txt"
filename <- basename(url) # filename <- "overview.txt"
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# check out the data
dim(d)
colnames(d)
head(d, n=1)
tail(d, n=1)
#str(d)
#glimpse(d)
summary(d)
table(d$Kingdom)

# gets rows for each condition
###   Archaea  Bacteria Eukaryota   Viruses 
d %>% filter(Kingdom == "Bacteria") %>% select(`Group`) %>% table
d %>% filter(Group == "PVC group") %>% select(`SubGroup`) %>% table

# Calculating summary statistics about groups of data
d %>% 
  group_by(Kingdom) %>% 
  summarise(medianSize = median(`Size (Mb)`, na.rm=TRUE))

d %>% filter(Group == "PVC group") %>% 
  group_by(`SubGroup`) %>% 
  summarise(number = n(),
            minSize = min(`Size (Mb)`, na.rm=TRUE),
            maxSize = max(`Size (Mb)`, na.rm=TRUE)) %>% 
  arrange(`maxSize`)

# make ggplot picture
ggplot(d, aes(x = `Chrs`, y = `Organelles`)) + geom_point()

d %>% filter(Group == "PVC group") %>% 
  ggplot(aes(x = `Size (Mb)`, y = `Plasmids`, colour = `SubGroup`)) + 
  geom_point(size = 1) + 
  xlab("Estimated genome size (Mb)") + 
  ylab("Number of plasmids") + 
  #scale_x_continuous(trans = "log10") +
  theme_bw()

#getwd()
#list.files()
sessionInfo()
Sys.time()

