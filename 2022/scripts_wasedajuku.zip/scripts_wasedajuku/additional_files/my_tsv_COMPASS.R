# Haruo Suzuki
# 2022-05-29
# This script is for the analysis of COMPASS Plasmid Database.

#' - https://r4ds.had.co.nz/introduction.html#the-tidyverse
#' - https://r4ds.had.co.nz/tibbles.html
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns.

# Loading Packages
library(tidyverse)

# Clear R's brain
rm(list = ls())

#' # Analysis of COMPASS, a New Comprehensive Plasmid Database Revealed Prevalence of Multireplicon and Extensive Diversity of IncF Plasmids
#' 
#' Front Microbiol. 2020 Mar 24;11:483. doi: 10.3389/fmicb.2020.00483. eCollection 2020.
#' Pierre-Emmanuel Douarre 1, Ludovic Mallet 1, Nicolas Radomski 1, Arnaud Felten 1, Michel-Yves Mistou 2
#' 
#' - https://www.ncbi.nlm.nih.gov/pubmed/32265894
#'   - https://www.frontiersin.org/articles/10.3389/fmicb.2020.00483/full
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7105883/
#' - https://github.com/itsmeludo/COMPASS
# Download File from the Internet
url <- "https://raw.githubusercontent.com/itsmeludo/COMPASS/master/data/COMPASS.tsv"
filename <- basename(url) # filename <- "COMPASS.tsv" # 3.0 MB
if(!file.exists(filename)) download.file(url = url, destfile = filename)

#' - https://r4ds.had.co.nz/data-import.html
d <- read_tsv(file=filename)

# Checking Data
dim(d)
colnames(d)
head(d, n=1)
tail(d, n=1)
#str(d)
#glimpse(d)
summary(d)

sessionInfo()
Sys.time()

