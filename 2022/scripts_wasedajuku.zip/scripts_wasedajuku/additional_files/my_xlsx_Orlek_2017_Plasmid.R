# Haruo Suzuki
# 2022-06-26
# This script is for Orlek et al. (2017) Plasmid. 91:42-52.

#' - https://r4ds.had.co.nz/introduction.html#the-tidyverse
#' - https://r4ds.had.co.nz/tibbles.html
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns.

# Loading Packages
#options(repos="https://cran.ism.ac.jp/")
#install.packages("readxl")
library(readxl)
library(tidyverse)

# Clear R's brain
rm(list = ls())

#' # Ordering the mob: Insights into replicon and MOB typing schemes from analysis of a curated dataset of publicly available plasmids
#' 
#' Plasmid. 2017 May;91:42-52. doi: 10.1016/j.plasmid.2017.03.002. Epub 2017 Mar 9.
#' Alex Orlek 1, Hang Phan 2, Anna E Sheppard 2, Michel Doumith 3, Matthew Ellington 4, Tim Peto 2, Derrick Crook 2, A Sarah Walker 2, Neil Woodford 4, Muna F Anjum 5, Nicole Stoesser 6
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/28286183/
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5466382/
#' | Associated Data
#' | Supplementary Materials
#' | Table S1 Details of the curated plasmids are provided including assigned replicon and MOB types, and detected resistance genes. The plasmids that were filtered at different stages of the curation process are shown. Results of applying our analysis pipeline to Enterobacteriaceae plasmids previously analysed by Shintani et al. are also shown.
# Download File from the Internet
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5466382/bin/mmc4.xlsx"
filename <- basename(url) # filename <- "mmc4.xlsx" # Table S1
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# List all sheets in an excel spreadsheet
excel_sheets(path=filename)

# Read xls and xlsx files
d <- read_excel(path=filename, sheet=2) # Plasmid typing
#d <- read_excel(path=filename, sheet=6) # Shintani et al.

#' # 3. Results and discussion
#' ## 3.1. Characteristics of the curated plasmid dataset
#' - leaving 2097 complete Enterobacteriaceae plasmids for analysis (Supplementary Table S1).
#' 
# Checking Data
dim(d)
colnames(d)
#head(d, n=1)
#tail(d, n=1)
#str(d)
#glimpse(d)
#summary(d)

#' - Plasmids ranged in size from 1.3 kb to 794 kb. 
#' The plasmid size distribution was log-bimodal (Supplementary Fig. S1) as reported previously (Shintani et al., 2015). 
#summary(d)
summary(d$`Plasmid_size`)
ggplot(d, aes(x = `Plasmid_size`)) + geom_histogram() + scale_x_log10()

sessionInfo()
Sys.time()
