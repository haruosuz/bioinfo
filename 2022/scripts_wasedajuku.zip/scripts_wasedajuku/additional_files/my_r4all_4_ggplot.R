#' ---
#' title: "Getting Started with R"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url) # filename <- "master.zip"
if(!file.exists(filename)){ download.file(url = url, destfile = filename); unzip(zipfile = filename); }

#' # 4 Visualizing Your Data
#' ## 4.1 The first step in every data analysis — making a picture
#' - [Beyond Bar and Line Graphs: Time for a New Data Presentation Paradigm](http://dx.doi.org/10.1371/journal.pbio.1002128)
#' - http://barbarplots.github.io/
#' 
#' ![](https://pbs.twimg.com/media/Cs3zkrVWcAAkmTB?format=jpg&name=small)
#' 
#' ## 4.2 ggplot2: a grammar for graphics
#' ## 4.2.1 MAKING A PICTURE—SCATTERPLOTS

#+ message = FALSE
# libraries I need (no need to install...)
library(tidyverse)

# clear the decks
rm(list = ls())

# get the data
compensation <- read.csv('datasets-master/compensation.csv', stringsAsFactors=TRUE)

# check out the data
glimpse(compensation)

# make my first ggplot picture
ggplot(compensation, aes(x = Root, y = Fruit)) + 
  geom_point()

#' Figure 4.1
#' 
#' ### 4.2.2 INTERPRETATION, THEN CUSTOMIZE
#' ### 4.2.3 THAT GREY BACKGROUND

# theme_bw()
ggplot(compensation, aes(x = Root, y = Fruit)) + 
  geom_point() +
  theme_bw()

# size
ggplot(compensation, aes(x = Root, y = Fruit)) + 
  geom_point(size = 5) +
  theme_bw()

# xlab() and ylab()
ggplot(compensation, aes(x = Root, y = Fruit)) + 
  geom_point(size = 5) +
  xlab("Root Biomass") +
  ylab("Fruit Production") +
  theme_bw()

# colour = Grazing
ggplot(compensation, aes(x = Root, y = Fruit, colour = Grazing)) + 
  geom_point(size = 5) + 
  xlab("Root Biomass") + 
  ylab("Fruit Production") + 
  theme_bw()

#' Figure 4.2

# shape = Grazing
ggplot(compensation, aes(x = Root, y = Fruit, shape = Grazing)) + 
  geom_point(size = 5) +
  xlab("Root Biomass") +
  ylab("Fruit Production") +
  theme_bw()

#' ## 4.3 Box-and-whisker plots
#' [Beyond Bar and Line Graphs: Time for a New Data Presentation Paradigm](http://dx.doi.org/10.1371/journal.pbio.1002128)

ggplot(compensation, aes(x = Grazing, y = Fruit)) + 
  geom_boxplot() +
  xlab("Grazing treatment") +
  ylab("Fruit Production") +
  theme_bw()

ggplot(compensation, aes(x = Grazing, y = Fruit)) + 
  geom_boxplot() +
  geom_point(size = 4, colour = 'lightgrey', alpha = 0.5) + 
  xlab("Grazing treatment") +
  ylab("Fruit Production") + 
  theme_bw()

#' Figure 4.3
#' 
#' ### 4.3.1 A MOMENT OF INTERPRETIVE CONTEMPLATION . . .
#' questions:
#' 
#' - Do plants with wider root diameters at the start of the experiment produce more fruit?
#' - Do grazed or ungrazed plants produce more fruit.
#' 
#' ## 4.4 Distributions: making histograms of numeric variables

ggplot(compensation, aes(x = Fruit)) + 
  geom_histogram()

ggplot(compensation, aes(x = Fruit)) + 
  geom_histogram(bins = 10)

ggplot(compensation, aes(x = Fruit)) + 
  geom_histogram(binwidth = 15)

#' ### 4.4.1 A NIFTY TOOL: FACETS

ggplot(compensation, aes(x = Fruit)) + 
  geom_histogram(binwidth = 15) + 
  facet_wrap(~Grazing)

#' Figure 4.6
#' 
#' ## 4.5 Saving your graphs for presentation, documents, etc.
#' 
ggsave("ThatCoolHistogtramOfFruit.png")

?ggsave

#' ## 4.6 Closing remarks

sessionInfo()


