# Haruo Suzuki
# 2022-06-26
# This script is for Merino et al. (2019) BMC Genomics. 20(1):92.

# Loading Packages
#options(repos="https://cran.ism.ac.jp/")
#install.packages("readxl")
library(readxl)
library(tidyverse)

# Clear R's brain
rm(list = ls())

#' # Comparative genomics of Bacteria commonly identified in the built environment
#' 
#' BMC Genomics. 2019 Jan 28;20(1):92. doi: 10.1186/s12864-018-5389-z.
#' Nancy Merino 1 2, Shu Zhang 3 4, Masaru Tomita 5 6, Haruo Suzuki 7 8
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/30691394/
#'   - https://bmcgenomics.biomedcentral.com/articles/10.1186/s12864-018-5389-z
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6350394/
#' Supplementary Materials
#' Additional file 1: 
#' 12864_2018_5389_MOESM1_ESM.xlsx (3.6M)
# Download File from the Internet
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6350394/bin/12864_2018_5389_MOESM1_ESM.xlsx"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# List all sheets in an excel spreadsheet
excel_sheets(path=filename)

#which(excel_sheets(path=filename) == "Table_S8_GenomeInfo")

# Read xls and xlsx files
d <- read_excel(path=filename, sheet=9, skip=1)

#' # Results
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6350394/#Sec2title
#' 
#' ## Genome size, GC content, and GC skew
#' We compared the genomic features (genome size, GC content, GC skew, and codon usage bias) of 
#' 2580 complete prokaryotic genomes from the NCBI RefSeq database, in which 
#' 717 genomes are from bacteria commonly identified in the BE (“Common BE genera”) and 
#' 1863 other genomes (“Other genera”) (Additional file 1: Table S8-S9). 
#' The “Other genomes” have not been identified in at least six publications 
#' (equivalent to 10% of the publications used for this study).

# Checking Data
dim(d)
colnames(d)
d$Common_BE <- d$BE >= 6
summary(d$Common_BE)
#' - https://r4ds.had.co.nz/transform.html#select
#' - https://www.trifields.jp/how-to-apply-summary-to-group_by-in-r-4488
#> iris %>% group_nest(Species) %>% mutate(s = map(data, ~ summary(.))) %>% pull(s, Species)
d %>% select(-(RefSeq:ORGANISM),-BE) %>% group_nest(`Common_BE`) %>% mutate(s = map(data, ~ summary(.))) %>% pull(s, `Common_BE`)
#' The “Common BE genomes” tended to have 
#' larger genome sizes (1.30–9.21 Mb, median 3.62 Mb) (Fig. 2a), 
#' higher GC contents (27.4–73.0%, median 46.6%) (Fig. 2b), and 
#' higher GCSI (0.007–0.629, median 0.19) (Fig. 2c) 
#' compared to the “Other genomes”.
#' 
#' ## Codon usage bias
#' The median S value of the “Common BE genomes” (1.32) was higher than that of the “Other genomes” (0.50), 

# geom_boxplot
for(index in c("Size (Mb)", "GC (%)", "GCSI", "S value")){
  p <- ggplot(d, aes(x = `Common_BE`, y = !!sym(index))) + geom_boxplot()
  print(p)
}

sessionInfo()
Sys.time()
