# Haruo Suzuki
# 2023-05-06
# This script is for Mori et al. (2018)

# Load Packages
library(readxl)
library(tidyverse)

# Clear R's brain
rm(list = ls())

#' # VITCOMIC2: visualization tool for the phylogenetic composition of microbial communities based on 16S rRNA gene amplicons and metagenomic shotgun sequencing
#' 
#' BMC Syst Biol. 2018 Mar 19;12(Suppl 2):30. doi: 10.1186/s12918-018-0545-2.
#' Hiroshi Mori 1, Takayuki Maruyama 2, Masahiro Yano 2, Takuji Yamada 2, Ken Kurokawa 3
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/29560821/
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5861490/
#' Supplementary Materials
#' Additional file 4: List of strain names in the 16S rRNA gene copy number reference database.
#' 12918_2018_545_MOESM4_ESM.xls (210K)
#' 
# Download File from the Internet
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5861490/bin/12918_2018_545_MOESM4_ESM.xls"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# List all sheets in an excel spreadsheet
excel_sheets(path=filename)

#which(excel_sheets(path=filename) == "copyDatabaseList.txt")

# Read xls and xlsx files
d <- read_excel(path=filename, sheet=1, skip=0)

#' # Implementation
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5861490/#Sec2title
#' 
#' ## Normalizing differences in 16S rRNA gene copy number among taxa
#' 
#' We obtained 1505 16S rRNA gene sequences, which thus comprised the 16S rRNA-CN DB (Additional file 4).
#' 
# Checking Data
dim(d)
colnames(d)
table(d$`Phylum or class nameb`)
summary(d$`16S rRNA gene copy number in the genome`)
colnames(d)[3] <- "Group"
colnames(d)[4] <- "16S_GCN"

# geom_bar
ggplot(data = d) + geom_bar(mapping = aes(x = `Group`)) + coord_flip()

# geom_boxplot
ggplot(d, aes(x = `Group`, y = `16S_GCN`)) + geom_boxplot() + coord_flip()

ggplot(data = d) + 
  geom_boxplot(mapping = aes(x = reorder(`Group`, `16S_GCN`, FUN = median), y = `16S_GCN`)) + 
  coord_flip() + xlab("Phylum/class")

#' ## VITCOMIC2 web system
#' - http://vitcomic.org/

sessionInfo()
Sys.time()
