#' ---
#' title: "[Getting Started with R](https://github.com/haruosuz/books/tree/master/r4all)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' # 1 Getting and Getting Acquainted with R
#' ## 1.1 Getting started
#' ## 1.2 Getting R
#' ## 1.3 Getting RStudio
#' ## 1.4 Let’splay
#' 
1+1
#' ## 1.5 Using R as a giant calculator (the size of your computer)
#' 
2 * 4
3/8
11.75 - 4.813
10^2
log(10)
log10(10)
sin(2 * pi)
7 < 10

#' Box 1.1: But what are functions?
#' 
#' ### 1.5.1 FROM THE SIMPLE TO THE SLIGHTLY MORE COMPLEX
1:10
#' ### 1.5.2 FUNCTIONS TAKE ARGUMENTS
#' 
seq(from = 1, to = 10, by = 1)
seq(from = 1, to = 10, by = 0.5)
#' ### 1.5.3 NOW FOR SOMETHING REALLY IMPORTANT
#' 
x <- seq(from = 1, to = 10, by = 0.5)
x
#' ### 1.5.4 HOW DOES R DO STUFF WITH VECTORS?
#' 
y <- seq(from = 101, to = 110, by = 0.5)
x + y
#' ## 1.6 Your first script
#' ### 1.6.1 THE SCRIPT PANE
#' 
# Clear R's brain
rm(list = ls())

#' ### 1.6.2 HOW DO I MAKE R DO STUFF, YOU ASK?
#' ### 1.6.3 TWO MORE BITS OF RSTUDIO MAGIC
#' ## 1.7 Intermezzo remarks
#' ## 1.8 Important functionality: packages
#install.packages("tidyverse")
#' ### 1.8.1 USING THE NEW FUNCTIONS THAT COME IN A PACKAGE
#' 
# make these packages and their associated functions
# available to use in this script
library(dplyr)
library(ggplot2)
#library(tidyverse)

#' ## 1.9 Getting help
?read.csv()

#' Box 1.2: Getting help from an R help file
#' 
#' ## 1.10 A mini-practical—some in-depth play
#' ## 1.11 Some more top tips and hints for a successful first (and more) R experience
#' ### 1.11.1 SAVING AND THE WORKSPACE OPTION
#' ### 1.11.2 SOME NICE THINGS ABOUT RSTUDIO
#' 
#' ## Appendix 1a Mini-tutorial solutions
#' 
# Exercise
rm(list = ls())
library(ggplot2)

# Exercise 1
# Plot a grah with x^2 on the y-axis and x on the x-axis.
x <- seq(-10, 10, 0.1)
y <- x^2
qplot(x, y, geom="line")

# Exercise 2
# Plot a grah with sine on the y-axis and x on the x-axis.
x <- seq(0, 8*pi, 0.1)
y <- sin(x)
qplot(x, y, geom="line")

# Exercise 3
# Plot a histogram of 1000 random normal deviates.
x <- rnorm(1000)
qplot(x)

#' ## Appendix 1b File extensions and operating systems

sessionInfo()
