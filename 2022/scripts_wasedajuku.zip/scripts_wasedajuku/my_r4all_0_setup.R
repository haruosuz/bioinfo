#' ## 1.8 Important functionality: packages
#' - https://cran.r-project.org/mirrors.html
# URLs of the repositories for use by update.packages
options(repos="https://cran.ism.ac.jp/")
install.packages("tidyverse")
install.packages("readxl")
library(tidyverse)
library(readxl)

#' ## 2.2 Getting your data into R
#' - http://r4all.org/books/datasets/
# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url) # filename <- "master.zip"
if(!file.exists(filename)){ download.file(url = url, destfile = filename); unzip(zipfile = filename); }

# Get Working Directory
getwd()

# List the Files in a Directory/Folder
list.files(path = ".")
list.files(path = "datasets-master")
