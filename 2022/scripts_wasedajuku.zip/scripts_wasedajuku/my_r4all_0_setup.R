#' ## 1.8 Important functionality: packages
options(repos="https://cran.ism.ac.jp/")

# Install Packages
install.packages("tidyverse")
install.packages("readxl")

# Load Packages
library(tidyverse)
library(readxl)

#' ## 2.2 Getting your data into R
#' - http://r4all.org/books/datasets/
# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url)
if(!file.exists(filename)){ download.file(url = url, destfile = filename); unzip(zipfile = filename); }

