# Haruo Suzuki
# 2023-06-11
# This script is for the analysis of prokaryotic pangenome

# Loading Packages
#options(repos="https://cran.ism.ac.jp/")
#install.packages("readxl")
library(readxl)
library(tidyverse)
library(psych) # pairs.panels
library(GGally) # ggpairs

# Clear R's brain
rm(list = ls())

#' # Disentangling the impact of environmental and phylogenetic constraints on prokaryotic within-species diversity
#' ISME J. 2020 May;14(5):1247-1259. doi: 10.1038/s41396-020-0600-z. Epub 2020 Feb 11.
#' Oleksandr M Maistrenko, ..., Peer Bork
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/32047279/
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7174425/
#' 
#' Supplementary Materials
#' Supplementary table 3
#' 41396_2020_600_MOESM3_ESM.xlsx (698K)
# Download File from the Internet
url <- ""
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7174425/bin/41396_2020_600_MOESM3_ESM.xlsx"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

excel_sheets(path=filename) # List all sheets in an excel spreadsheet
which(excel_sheets(path=filename) == "SupplTab2")
d <- read_excel(path=filename, sheet=1, skip=2) # Read xls and xlsx files

# Check out the data
dim(d) # Display the dimensions (number of rows and columns) of the data frame
#colnames(d) # Print the column names of the data frame
head(colnames(d), n=30)
#str(d)

# `grepl` returns a logical vector (match or not for each element of x)
# Set Organism name of interest
my_name <- "Bifidobacterium|Lactobacillus"
TF <- grepl(pattern=my_name, x=d$`Species_name`); summary(TF)
myd <- d[TF,]

#' sort
myd <- myd %>% arrange(desc(`mean_genome`)); #View(myd)

# Export
write_csv(myd, paste0("my.", filename,".csv"))
#write_tsv(myd, paste0("my.", filename,".tsv"))

# Statistics
head(colnames(d), n=30) # "core"        "pan"         "mean_genome"
my_pattern <- paste0("^", colnames(d)[c(21,23,27)], "$", collapse="|")
TF <- grepl(pattern=my_pattern, x=colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
myd %>% select(mycol) %>% summary
d %>% select(mycol) %>% pairs.panels
#d %>% select(mycol) %>% ggpairs

#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7174425/#Sec8title
#' 
#' ## Results
#' ### Interdependencies of pangenome features
#' (see Supplementary Table 3 for estimates of pangenome features,
#' 
#' Estimates of pangenome size and the size of its components (core, shell, and cloud) are strongly correlated with each other (Fig. 2a). 
#' 
#' mean genome size strongly correlated with several features, including core-genome size, pangenome size
#' 

sessionInfo()
Sys.time()
