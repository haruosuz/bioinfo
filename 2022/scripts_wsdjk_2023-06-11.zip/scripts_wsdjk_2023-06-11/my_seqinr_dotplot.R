# Haruo Suzuki
# 2023-05-28
# This script is for comparing two protein sequences using a dotplot

#' # dotplot
#' ## [ドットプロットで2つの配列を比較](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot)
#' [相同性検索(アライメント)の威力](https://www.dna.bio.keio.ac.jp/lecture/bioinfo/bioinformatics-3.pdf)
#' ヒトの[血小板由来成長因子](https://ja.wikipedia.org/wiki/血小板由来成長因子) (Platelet-Derived Growth Factor, PDGF) と [サル肉腫ウイルスの癌遺伝子 v-sis](https://www.wikigenes.org/e/mesh/e/21827.html) のアミノ酸配列は類似性が高い。([Doolittle RF et al., 1983](https://www.ncbi.nlm.nih.gov/pubmed/6304883))

rm(list = ls()) # Clear R's environment
library(seqinr) # Loading the "seqinr" package 

#' ## Download FASTA-format files of two protein sequences from NCBI
accession1 <- "P01127" # Replace this accession number with the desired one
accession2 <- "P01128" # Replace this accession number with the desired one
chars1 <- read.fasta(file = paste0("http://togows.dbcls.jp/entry/protein/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file = paste0("http://togows.dbcls.jp/entry/protein/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
#write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

#' ## Comparing two sequences using a dotplot
dotPlot(chars1, chars2)
#dotPlot(s2c("tgca"), s2c("tgca"))

sessionInfo() # Print information about the R session, including the version and loaded packages
Sys.time() # Get the current system time

