# Haruo Suzuki
# 2023-06-10
# This script is for Elizabeth Hénaff et al. (2023) Environ Microbiome

# Loading Packages
#options(repos="https://cran.ism.ac.jp/")
#install.packages("readxl")
library(readxl)
library(tidyverse)

# Clear R's brain
rm(list = ls())

#' # Holobiont Urbanism: sampling urban beehives reveals cities' metagenomes
#' Environ Microbiome. 2023 Mar 30;18(1):23. doi: 10.1186/s40793-023-00467-z.
#' Elizabeth Hénaff 1 2, Devora Najjar 3, Miguel Perez 3, Regina Flores 4, Christopher Woebken 5, Christopher E Mason 6 7 8, Kevin Slavin 3
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/36991491/
#'   - https://twitter.com/MicrobiomeJ/status/1641499976424386560
#'   - https://environmentalmicrobiome.biomedcentral.com/articles/10.1186/s40793-023-00467-z
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10060141/
#' Associated Data
#' Supplementary Materials
#' Additional file 7. Metadata for all samples in MIXS format.
#' 40793_2023_467_MOESM7_ESM.xlsx (20K)
# Download File from the Internet
url <- ""
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10060141/bin/40793_2023_467_MOESM7_ESM.xlsx"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# List all sheets in an excel spreadsheet
excel_sheets(path=filename)

#which(excel_sheets(path=filename) == "Sheet1")

# Read xls and xlsx files
d <- read_excel(path=filename, sheet=1, skip=0)

# Checking Data
dim(d)
colnames(d)
str(d)

# geom_boxplot
for(index in c("collection_date", "lib_reads_seqd")){
  p <- ggplot(d, aes(x = `geo_loc_name`, y = !!sym(index))) + geom_boxplot()
  print(p)
}

sessionInfo()
Sys.time()
