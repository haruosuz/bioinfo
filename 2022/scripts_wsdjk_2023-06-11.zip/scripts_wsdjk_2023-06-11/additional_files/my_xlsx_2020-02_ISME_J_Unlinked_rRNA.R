# Haruo Suzuki
# 2023-06-10
# This script is for the analysis of unlinked rRNA genes.

# Install R packages
#options(repos = "https://cran.ism.ac.jp/")
#install.packages("psych")
#install.packages("GGally")

# Loading Packages
#options(repos="https://cran.ism.ac.jp/")
#install.packages("readxl")
library(readxl)
library(tidyverse)
library(tidyverse)
library(psych) # pairs.panels
library(GGally) # ggpairs

# Clear R's brain
rm(list = ls())

#' # Unlinked rRNA genes are widespread among bacteria and archaea
#' ISME J. 2020 Feb;14(2):597-608. doi: 10.1038/s41396-019-0552-3. Epub 2019 Nov 11.
#' Tess E Brewer 1 2, Mads Albertsen 3, Arwyn Edwards 4, Rasmus H Kirkegaard 3, Eduardo P C Rocha 5, Noah Fierer 6 7
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/31712737/
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6976660/
#' 
#' Supplementary Materials
#' Dataset S1 and Dataset S2
#' 41396_2019_552_MOESM1_ESM.xlsx (3.1M)
# Download File from the Internet
url <- ""
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6976660/bin/41396_2019_552_MOESM1_ESM.xlsx"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

excel_sheets(path=filename) # List all sheets in an excel spreadsheet
which(excel_sheets(path=filename) == "Dataset S1")
d <- read_excel(path=filename, sheet=2, skip=0) # Read xls and xlsx files

# Check out the data
dim(d) # Display the dimensions (number of rows and columns) of the data frame
colnames(d) # Print the column names of the data frame
#str(d)

# `grepl` returns a logical vector (match or not for each element of x)
my_name <- "Lactobacillus|Buchnera" # Set Organism/Name of interest
TF <- grepl(pattern=my_name, x=d$`genome_name`); summary(TF)
myd <- d[TF,]

# Sory by Size
TF <- grepl(pattern = "genome_size", x = colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
myd <- myd %>% arrange(desc(!!sym(mycol))); #View(myd)

# Export
write_csv(myd, paste0("my.", filename,".csv"))
#write_tsv(myd, paste0("my.", filename,".tsv"))

# Statistics
TF <- grepl(pattern = "genome_size|rRNA_number|delta_ENC", x = colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
myd %>% select(mycol) %>% summary

ggplot(myd, aes(x = `genome_size`)) + geom_histogram() + facet_wrap(~ `genome_rRNA_status`, ncol = 1)

for(index in mycol){
  p <- ggplot(myd, aes(x = !!sym(index))) + geom_histogram() + facet_wrap(~ `genome_rRNA_status`, ncol = 1)
  print(p)
}

sessionInfo()
Sys.time()
