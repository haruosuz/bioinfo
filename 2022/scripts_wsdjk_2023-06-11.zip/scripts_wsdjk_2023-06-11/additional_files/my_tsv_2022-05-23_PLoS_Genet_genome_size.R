# Haruo Suzuki
# 2023-05-27
# This script is for the analysis of Genome size.

#' - https://r4ds.had.co.nz/introduction.html#the-tidyverse
#' - https://r4ds.had.co.nz/tibbles.html
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns.

# Loading Packages
library(tidyverse)

# Clear R's brain
rm(list = ls())

#' # Genome size distributions in bacteria and archaea are strongly linked to evolutionary history at broad phylogenetic scales
#' PLoS Genet. 2022 May 23;18(5):e1010220. doi: 10.1371/journal.pgen.1010220. eCollection 2022 May.
#' Carolina A Martinez-Gutierrez 1, Frank O Aylward 1 2
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/35605022/
#'   - https://journals.plos.org/plosgenetics/article?id=10.1371/journal.pgen.1010220
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9166353/
#'   Supplementary Materials
#'   - S1 Data: Genomes used to calculate pairwise dN/dS within each genus cluster. (TSV)
#'   - S2 Data: dN/dS, genome size, and rrn operon copies for each genus representative. (TSV)
#'   
#' - https://r4ds.had.co.nz/data-import.html
# Download File from the Internet
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9166353/bin/pgen.1010220.s001.tsv"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)
d.S1 <- read_tsv(file=filename)

url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9166353/bin/pgen.1010220.s002.tsv"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)
d.S2 <- read_tsv(file=filename)

#' - https://r4ds.had.co.nz/relational-data.html
#' - https://r4ds.hadley.nz/joins.html

d <- right_join(x = d.S1, y = d.S2, by = "Genome")
d$Phylum <- gsub(pattern=".+;p__([^ ]+);c__.+", replacement="\\1", x=d$`Taxonomy`)

# Checking Data
dim(d)
colnames(d)
head(d, n=1)
tail(d, n=1)
#str(d)
#glimpse(d)
summary(d)

#' ## 4.4 Distributions: making histograms of numeric variables
ggplot(d, aes(x = `Genome_Size_Mbp`)) + geom_histogram()
#' 
#' ## 4.3 Box-and-whisker plots
#' [Beyond Bar and Line Graphs: Time for a New Data Presentation Paradigm](http://dx.doi.org/10.1371/journal.pbio.1002128)
ggplot(d, aes(x = `Phylum`, y = `Genome_Size_Mbp`)) + 
  geom_boxplot(mapping = aes(x = reorder(`Phylum`, `Genome_Size_Mbp`, FUN = median), y = `Genome_Size_Mbp`)) + 
  geom_point(size = 1, colour = 'lightgrey', alpha = 0.5) + 
  coord_flip()
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9166353/figure/pgen.1010220.g001/
#' #' Fig 1
#' A) Distribution of genome size within bacteria and archaea taxonomic groups at the phylum level. First and third quantiles, as well as median are shown for each phylum distribution. 
#' 
#' ## 4.2 ggplot2: a grammar for graphics
#' ### 4.2.1 MAKING A PICTURE—SCATTERPLOTS
# make my first ggplot picture
ggplot(d, aes(x = `rrn_Operon_Copies`, y = `Genome_Size_Mbp`)) + geom_point()
#' ### 4.2.2 INTERPRETATION, THEN CUSTOMIZE
ggplot(d, aes(x = `rrn_Operon_Copies`, y = `Genome_Size_Mbp`)) + 
  geom_point(size = 3, colour = 'red', alpha = 0.5) + 
  xlab("16S rRNA copies") + 
  ylab("Genome Size (Mbp)") + 
  theme_bw()
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9166353/figure/pgen.1010220.g003/
#' Fig 3
#' Relationship between genome size and genomic traits for bacteria and archaea using one representative genome for each genus.
#' 
sessionInfo()
Sys.time()

#' - https://github.com/haruosuz/books/tree/master/r4all
#' 
#' 

