# Haruo Suzuki
# 2023-07-08
# This script is for the analysis of eukaryotic genome content

# Loading Packages
#options(repos="https://cran.ism.ac.jp/")
#install.packages("readxl")
library(readxl)
library(tidyverse)
library(psych) # pairs.panels
library(GGally) # ggpairs

# Clear R's brain
rm(list = ls())

#' # What's in a genome? The C-value enigma and the evolution of eukaryotic genome content
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/26323762/
#'   - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4571570/
#' 
#' Supplementary Materials
#' Supplement 1
#' rstb20140331supp1.xlsx (220K)
# Download File from the Internet
url <- ""
url <- "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4571570/bin/rstb20140331supp1.xlsx"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

excel_sheets(path=filename) # List all sheets in an excel spreadsheet
which(excel_sheets(path=filename) == "Genomic parameters data set")
d <- read_excel(path=filename, sheet=1, skip=0) # Read xls and xlsx files

# Check out the data
dim(d) # Display the dimensions (number of rows and columns) of the data frame
str(d)

# Set Organism "Species" "Taxon Group" "Common Name" of interest
# `grepl` returns a logical vector (match or not for each element of x)
# Taxon Group
table(d$`Taxon Group`)
my_name <- "Animal"
TF <- grepl(pattern=my_name, x=d$`Taxon Group`); summary(TF)
# Species
my_name <- "Gallus gallus|Mus musculus|Mus musculus|Homo sapiens|Bos taurus"
TF <- grepl(pattern=my_name, x=d$`Species`); summary(TF)
# Common Name
my_name <- "Chicken|Mouse|Gorilla|Human|Cow"
TF <- grepl(pattern=my_name, x=d$`Common Name`); summary(TF)
#
myd <- d[TF,]

#' - https://qiita.com/zakkiiii/items/e504756aa96375f8fc41
#colnames(d) # Print the column names of the data frame
my_pattern <- colnames(d)[4]
my_pattern <- gsub(pattern="[()]", replacement=".", x=my_pattern)
TF <- grepl(pattern=my_pattern, x=colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
myd <- myd %>% arrange(desc(!!sym(mycol))); #View(myd)

# Export
write_csv(myd, paste0("my.", filename,".csv"))
#write_tsv(myd, paste0("my.", filename,".tsv"))

# Statistics
#my_pattern <- paste0("^", colnames(d)[c(4,13,14)], "$", collapse="|")
#my_pattern <- gsub(pattern="[()]", replacement=".", x=my_pattern)
#TF <- grepl(pattern=my_pattern, x=colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
mycol <- c("Estimated Genome Size (Mb)", "Gene Number"); mycol
myd %>% select(mycol) %>% summary
myd %>% select(mycol) %>% plot
#myd %>% select(mycol) %>% pairs.panels(smooth=FALSE, density=FALSE, ellipses=FALSE)
#myd %>% select(mycol) %>% ggpairs

#getwd()        # get the current working directory
#list.files()   # list files in the current working directory
#sessionInfo()  # get information about the R session
Sys.time()      # Print the current system time
