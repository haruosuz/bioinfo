# Haruo Suzuki
# 2023-06-24
# This script is for the analysis of TEMPURA

# Loading Packages
library(tidyverse)
library(psych) # pairs.panels
library(GGally) # ggpairs

# Clear R's brain
rm(list = ls())

#' # TEMPURA: Database of Growth TEMPeratures of Usual and RAre Prokaryotes
#' 
#' - https://pubmed.ncbi.nlm.nih.gov/32727974/
#' - http://togodb.org/db/tempura
# Download File from the Internet
url <- "http://togodb.org/release/200617_TEMPURA.csv"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.csv(file=filename, check.names=FALSE, stringsAsFactors=TRUE)

# Checking Data
dim(d)
head(d, n=1)
tail(d, n=1)
#colnames(d)
str(d)
summary(d)

# `grepl` returns a logical vector (match or not for each element of x)
# Set Organism name of interest
d$taxonomy <- apply(d[,c("superkingdom", "phylum","class","order","family","genus", "genus_and_species")], 1, paste0, collapse="; ")
my_name <- "Proteobacteria" # phylum
my_name <- "Gammaproteobacteria" # class
my_name <- "Alteromonadales" # order
my_name <- "Shewanellaceae" # family
#my_name <- "Bifidobacterium|Lactobacillus|Shewanella" # genus
#my_name <- "Methanopyrus kandleri" # genus_and_species
TF <- grepl(pattern=my_name, x=d$taxonomy); summary(TF)
myd <- d[TF,]

#' sort
myd <- myd %>% arrange(desc(`Genome_size`)); #View(myd)

# Export
#write_csv(myd, paste0("my.", filename,".csv"))
#write_tsv(myd, paste0("my.", filename,".tsv"))

# Statistics
colnames(d) # Genome_GC	Genome_size	16S_GC	Topt_ave
mycol <- c("Genome_size", "Genome_GC", "16S_GC", "Topt_ave")
myd %>% select(mycol) %>% summary
myd %>% select(mycol) %>% pairs.panels
#myd %>% select(mycol) %>% ggpairs

sessionInfo()
Sys.time()
