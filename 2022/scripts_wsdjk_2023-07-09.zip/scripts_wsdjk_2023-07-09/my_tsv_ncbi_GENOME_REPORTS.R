# Haruo Suzuki
# 2023-07-08
# This script is for the analysis of NCBI GENOME_REPORTS

# Clear R's environment
rm(list = ls())

# Load R packages
library(tidyverse)
library(psych) # pairs.panels
library(GGally) # ggpairs

#' # NCBI GENOME_REPORTS
#' - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/
#' On this page, right click on the link to the file (eukaryotes.txt, overview.txt, plasmids.txt, prokaryotes.txt, viruses.txt), and select "Copy Link Address".
#'   - https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/README
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/eukaryotes.txt"
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/overview.txt"
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/plasmids.txt" # "Size (Kb)" "GC%" "Protein" "rRNA" "tRNA" "Other RNA" "Gene"
#url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/prokaryotes.txt"
#url <- "https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/viruses.txt"
filename <- basename(url); filename
# Set Organism/Name of interest
if(filename == "eukaryotes.txt") myOrganism <- "Oryzias|Gambusia" # "Hypsibius|Paramacrobiotus|Ramazzottius" # "Plasmodium"
if(filename == "overview.txt") myOrganism <- "coronavirus"
if(filename == "plasmids.txt") myOrganism <- "Wolbachia"
if(filename == "prokaryotes.txt") myOrganism <- "Bifidobacterium" # "Lactobacillus"
if(filename == "viruses.txt") myOrganism <- "Dengue virus|Zika virus"
myOrganism

# Download File from the Internet
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read.delim(file=filename, quote="", stringsAsFactors=FALSE, na.strings="-", check.names=FALSE)

# Check out the data
dim(d)           # Display the dimensions (number of rows and columns) of the data frame
colnames(d)      # Print the column names of the data frame

# `grepl` returns a logical vector (match or not for each element of x)
TF <- grepl(pattern=myOrganism, x=d$`#Organism/Name`, ignore.case=TRUE); summary(TF)
myd <- d[TF,]

# check genome status, exclude draft genomes
#table(myd$Status)
#TF <- grepl(pattern="Contig|Scaffold", x=myd$`Status`, ignore.case=TRUE); summary(TF); myd <- myd[!TF,]

# Display the first and last few rows of the data frame
head(myd, n = 2)
tail(myd, n = 2)

# Sory by Size
TF <- grepl(pattern = "Size", x = colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
myd <- myd %>% arrange(desc(!!sym(mycol))); #View(myd)

# Export
write_csv(myd, paste0("my.", filename,".csv"))
#write_tsv(myd, paste0("my.", filename,".tsv"))

# Statistics
TF <- grepl(pattern = "Size|Gene|Chrs", x = colnames(myd)); summary(TF); mycol <- colnames(myd)[TF]; mycol
myd %>% select(mycol) %>% summary
myd %>% select(mycol) %>% plot
#myd %>% select(mycol) %>% pairs.panels(smooth=FALSE, density=FALSE, ellipses=FALSE)
#myd %>% select(mycol) %>% ggpairs

#getwd()        # get the current working directory
#list.files()   # list files in the current working directory
#sessionInfo()  # get information about the R session
Sys.time()      # Print the current system time

#' # References
#' - https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ncbi-genome-list
#' - https://www.ncbi.nlm.nih.gov/genome/browse
#' - https://en.wikipedia.org/wiki/Taxonomic_rank
#' ![https://www.biologyonline.com/dictionary/taxonomy](https://www.biologyonline.com/wp-content/uploads/2020/09/taxonomy-definition-and-example-diagram-768x432.jpg)
#' 
