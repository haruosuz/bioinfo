# Haruo Suzuki
# 2023-11-09
# This script is for comparing two protein sequences using a dotplot

#' # dotplot
#' ## [ドットプロットで2つの配列を比較](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot)
#' ## [Comparing two sequences using a dotplot](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)

rm(list = ls()) # Clear R's environment
library(seqinr) # Loading the "seqinr" package 

#' ## Download FASTA-format files of two protein sequences from UniProt.
accession1 <- "Q9CD83" # Change the accession number
accession2 <- "P9WIC5" # Change the accession number
chars1 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

# Write sequence(s) into a file in fasta format
#write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
#write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

#' ## Comparing two sequences using a dotplot
#chars1 <- chars2 <- s2c("acgt")
dotPlot(chars1, chars2)
#dotPlot(chars1, chars2, wsize = 2, wstep = 2, nmatch = 2)

#' Collect Information About the Current R Session
sessionInfo()
