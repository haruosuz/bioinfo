# Haruo Suzuki
# 2023-11-09
# This script is for setting up the environment, including package installation and data import into R

#' - https://cran.r-project.org/mirrors.html
# URLs of the repositories for use by install.packages
options(repos="https://cran.ism.ac.jp/")

#' [R will ignore any text after `#` for that line.](https://r4ds.hadley.nz/workflow-basics.html#comments)
#R.version

# Install R packages
#install.packages("seqinr")

# Install Bioconductor packages:  
#if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
#BiocManager::install("Biostrings")

# Print the versions of these packages:  
packageVersion("seqinr")
packageVersion("Biostrings")

# Load the R packages into R:  
library(seqinr)
library(Biostrings)

#' Get and report version information about R, the OS and attached or loaded packages.
sessionInfo()

#' # References
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#installing-r-packages
