# Haruo Suzuki
# 2023-11-09
# This script is for DNA sequence analysis using the seqinR package

#' # DNA Sequence Statistics
#' ## [DNA配列の統計 (1)](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1)
#' ## [DNA Sequence Statistics (1)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter1.html)

rm(list = ls()) # Clear R's environment
library(seqinr) # Loading the "seqinr" package 

# Retrieving a DNA sequence from NCBI
ACCESSION <- "NC_045512" # Modify the accession number
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")
seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fasta") )

seq1 <- seqs[[1]]
getAnnot(seq1) # Get sequence annotations
#seq1 <- s2c("aatgc") # create a test DNA sequence
seq1[2:3] # obtain nucleotides 2-3 of DNA sequence stored in the vector `seq1`
length(seq1) # length of the DNA sequence
table(seq1) # base composition
GC(seq1) # GC content = (G+C)/(A+T+G+C)
count(seq1, wordsize = 2) # k-mer count
rho(seq1, wordsize = 2) # k-mer relative abundance


#' Collect Information About the Current R Session
sessionInfo()