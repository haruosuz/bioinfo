cat("# Scripts should not use `setwd()` to set their working directory, as this is not portable to other systems (which won’t have the same directory structure).\n")
cat("# use relative paths when loading in data, and not absolute paths\n")
cat("# indicate which directory the user should set as their working directory.\n")
sessionInfo()