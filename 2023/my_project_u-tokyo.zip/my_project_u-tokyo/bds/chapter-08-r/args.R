## args.R -- a simple script to show command line args
args <- commandArgs(TRUE)
print(args)

# We run this with:
# Rscript --vanilla args.R arg1 arg2 arg3
